import jsPDF from "jspdf";

interface SignatureData {
  signerType: string;
  signerName: string;
  signerMatricula?: string | null;
  signatureData: string;
  signedAt: string;
}

interface PhotoEntry {
  type: "machine_code" | "before" | "after";
  data: string;
}

interface ConfirmationData {
  id: number;
  employeeMatricula: string;
  coWorkerMatricula?: string | null;
  startDate?: string | null;
  startTime?: string | null;
  endDate?: string | null;
  endTime?: string | null;
  realWork?: number | null;
  observation?: string | null;
  justification?: string | null;
  rootCauseId?: number | null;
  photos?: string | null;
  status: string;
}

interface LineData {
  opNumber: string;
  subOp?: string | null;
  centTrab?: string | null;
  description: string;
  expectedTime?: number | null;
  confirmations?: ConfirmationData[];
}

interface OrderData {
  orderNumber: string;
  description: string;
  type: string;
  status: string;
  equipment?: string | null;
  costCenter?: string | null;
  location?: string | null;
  openDate?: string | null;
  activityType?: string | null;
  area?: string | null;
  center?: string | null;
  assignedName?: string | null;
  assignedMatricula?: string | null;
  lines?: LineData[];
}

const SIGNER_LABELS: Record<string, string> = {
  executor: "Executor",
  area_responsible: "Resp. Área / Solicitante",
  immediate_supervisor: "Supervisão Imediata",
};

const STATUS_LABELS: Record<string, string> = {
  open: "Aberta",
  in_progress: "Em Andamento",
  completed: "Concluída",
};

const TYPE_LABELS: Record<string, string> = {
  preventive: "Preventiva",
  corrective: "Corretiva",
};

function addPageIfNeeded(doc: jsPDF, y: number, needed = 20): { doc: jsPDF; y: number } {
  if (y + needed > 272) {
    doc.addPage();
    return { doc, y: 14 };
  }
  return { doc, y };
}

function drawSectionTitle(doc: jsPDF, text: string, x: number, y: number): number {
  doc.setFontSize(9);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(15, 23, 42);
  doc.text(text, x, y);
  return y + 5;
}

export function exportOrderPdf(order: OrderData, signatures: SignatureData[]) {
  const doc = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
  const W = 210;
  const margin = 14;
  const contentWidth = W - margin * 2;
  let y = 14;

  // ── Header ─────────────────────────────────────────────────────────────────
  doc.setFillColor(15, 23, 42);
  doc.rect(0, 0, W, 28, "F");
  doc.setTextColor(249, 115, 22);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.text("GeoLab", margin, 11);
  doc.setTextColor(255, 255, 255);
  doc.setFontSize(9);
  doc.setFont("helvetica", "normal");
  doc.text("Sistema de Apontamento de Manutenção", margin, 18);
  doc.setFontSize(8);
  doc.text(`Gerado em: ${new Date().toLocaleString("pt-BR")}`, margin, 24);
  doc.setFontSize(18);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(249, 115, 22);
  doc.text(`OS ${order.orderNumber}`, W - margin, 16, { align: "right" });

  y = 36;

  // ── Title ──────────────────────────────────────────────────────────────────
  doc.setTextColor(15, 23, 42);
  doc.setFontSize(13);
  doc.setFont("helvetica", "bold");
  doc.text(order.description, margin, y);
  y += 6;

  const typeTxt = TYPE_LABELS[order.type] || order.type;
  const statusTxt = STATUS_LABELS[order.status] || order.status;
  doc.setFontSize(8);
  doc.setFont("helvetica", "normal");
  doc.setTextColor(100, 116, 139);
  doc.text(`${typeTxt}  •  ${statusTxt}`, margin, y);
  y += 8;

  // ── Details grid ──────────────────────────────────────────────────────────
  doc.setDrawColor(226, 232, 240);
  doc.setLineWidth(0.3);
  doc.line(margin, y, W - margin, y);
  y += 5;

  const fields: [string, string][] = [
    ["Equipamento", order.equipment || "-"],
    ["Centro de Custo", order.costCenter || "-"],
    ["Local", order.location || "-"],
    ["Data Abertura", order.openDate || "-"],
    ["Tipo de Atividade", order.activityType || "-"],
    ["Área", order.area || "-"],
    ["Centro", order.center || "-"],
    ["Responsável", order.assignedName || order.assignedMatricula || "-"],
  ];

  const colW = contentWidth / 2;
  fields.forEach(([label, value], i) => {
    const col = i % 2;
    const row = Math.floor(i / 2);
    const x = margin + col * colW;
    const fy = y + row * 8;
    doc.setFontSize(7.5);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(100, 116, 139);
    doc.text(label + ":", x, fy);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(30, 41, 59);
    const maxLen = 28;
    doc.text(value.length > maxLen ? value.slice(0, maxLen - 1) + "…" : value, x + 32, fy);
  });

  y += Math.ceil(fields.length / 2) * 8 + 4;
  doc.line(margin, y, W - margin, y);
  y += 6;

  // ── Operations + Confirmation History ─────────────────────────────────────
  if (order.lines && order.lines.length > 0) {
    const r = addPageIfNeeded(doc, y, 12);
    y = r.y;
    y = drawSectionTitle(doc, "Operações e Apontamentos", margin, y);

    for (const line of order.lines) {
      const doneConfs = (line.confirmations || []).filter(
        (c) => c.status === "finished" || c.status === "edited"
      );

      // Check space needed for this line block
      const spaceNeeded = 10 + doneConfs.length * 30;
      const pg = addPageIfNeeded(doc, y, spaceNeeded);
      y = pg.y;

      // Line header row
      doc.setFillColor(241, 245, 249);
      doc.rect(margin, y, contentWidth, 7, "F");
      doc.setFontSize(8);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(30, 41, 59);
      doc.text(
        `OP ${line.opNumber}${line.subOp ? `.${line.subOp}` : ""}${line.centTrab ? `  |  ${line.centTrab}` : ""}`,
        margin + 2, y + 5
      );
      if (line.expectedTime) {
        doc.setFontSize(7.5);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(100, 116, 139);
        doc.text(`Prev: ${line.expectedTime}h`, W - margin - 2, y + 5, { align: "right" });
      }
      y += 8;

      // Line description
      doc.setFontSize(7.5);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(30, 41, 59);
      const descLines = doc.splitTextToSize(line.description, contentWidth - 4);
      doc.text(descLines, margin + 2, y);
      y += descLines.length * 4 + 3;

      // Confirmation history
      if (doneConfs.length > 0) {
        for (const conf of doneConfs) {
          const pg2 = addPageIfNeeded(doc, y, 28);
          y = pg2.y;

          // Confirmation sub-header
          doc.setFillColor(248, 250, 252);
          doc.rect(margin + 4, y, contentWidth - 4, 6, "F");
          doc.setFontSize(7);
          doc.setFont("helvetica", "bold");
          doc.setTextColor(100, 116, 139);
          doc.text("Apontamento:", margin + 6, y + 4);
          doc.setFont("helvetica", "normal");
          const timeStr = `${conf.startDate || ""} ${(conf.startTime || "").slice(0, 5)} → ${conf.endDate || ""} ${(conf.endTime || "").slice(0, 5)}`;
          doc.text(timeStr, margin + 35, y + 4);
          if (conf.realWork != null) {
            doc.setFont("helvetica", "bold");
            doc.setTextColor(15, 23, 42);
            doc.text(`${conf.realWork}h trabalhadas`, W - margin - 2, y + 4, { align: "right" });
          }
          y += 7;

          // Executor
          doc.setFontSize(7);
          doc.setFont("helvetica", "normal");
          doc.setTextColor(30, 41, 59);
          let execLine = `Executor: ${conf.employeeMatricula}`;
          if (conf.coWorkerMatricula) execLine += `  |  Ajudante: ${conf.coWorkerMatricula}`;
          doc.text(execLine, margin + 6, y);
          y += 5;

          // Observation
          if (conf.observation) {
            const pg3 = addPageIfNeeded(doc, y, 10);
            y = pg3.y;
            doc.setFont("helvetica", "bold");
            doc.setTextColor(100, 116, 139);
            doc.text("Obs:", margin + 6, y);
            doc.setFont("helvetica", "normal");
            doc.setTextColor(30, 41, 59);
            const obsLines = doc.splitTextToSize(conf.observation, contentWidth - 20);
            doc.text(obsLines, margin + 16, y);
            y += obsLines.length * 4 + 2;
          }

          // Justification
          if (conf.justification) {
            const pg4 = addPageIfNeeded(doc, y, 10);
            y = pg4.y;
            doc.setFont("helvetica", "bold");
            doc.setTextColor(200, 80, 20);
            doc.text("Justif.:", margin + 6, y);
            doc.setFont("helvetica", "normal");
            const justLines = doc.splitTextToSize(conf.justification, contentWidth - 22);
            doc.text(justLines, margin + 20, y);
            y += justLines.length * 4 + 2;
          }

          // Photos
          if (conf.photos) {
            try {
              const photos: PhotoEntry[] = JSON.parse(conf.photos);
              const validPhotos = photos.filter((p) => p.data && p.data.startsWith("data:image"));
              if (validPhotos.length > 0) {
                const pg5 = addPageIfNeeded(doc, y, 38);
                y = pg5.y;

                doc.setFont("helvetica", "bold");
                doc.setFontSize(7);
                doc.setTextColor(100, 116, 139);
                doc.text("Fotos:", margin + 6, y);
                y += 4;

                const photoLabels: Record<string, string> = {
                  machine_code: "Código/Tag",
                  before: "Antes",
                  after: "Depois",
                };
                const photoW = 38;
                const photoH = 28;
                const gap = 4;
                let photoX = margin + 6;

                for (const photo of validPhotos) {
                  const pg6 = addPageIfNeeded(doc, y, photoH + 8);
                  if (pg6.y !== y) {
                    y = pg6.y;
                    photoX = margin + 6;
                  }

                  if (photoX + photoW > W - margin) {
                    y += photoH + 8;
                    photoX = margin + 6;
                    const pg7 = addPageIfNeeded(doc, y, photoH + 8);
                    y = pg7.y;
                  }

                  try {
                    // Determine image format from data URL
                    const fmt = photo.data.includes("data:image/png") ? "PNG" : "JPEG";
                    doc.addImage(photo.data, fmt, photoX, y, photoW, photoH);
                    doc.setDrawColor(203, 213, 225);
                    doc.setLineWidth(0.3);
                    doc.rect(photoX, y, photoW, photoH, "S");
                    // Label below photo
                    doc.setFontSize(6.5);
                    doc.setFont("helvetica", "normal");
                    doc.setTextColor(100, 116, 139);
                    doc.text(photoLabels[photo.type] || photo.type, photoX + photoW / 2, y + photoH + 3.5, { align: "center" });
                  } catch {}

                  photoX += photoW + gap;
                }

                y += photoH + 8;
              }
            } catch {}
          }

          y += 3;
          doc.setDrawColor(226, 232, 240);
          doc.setLineWidth(0.2);
          doc.line(margin + 4, y, W - margin, y);
          y += 4;
        }
      } else {
        doc.setFontSize(7);
        doc.setFont("helvetica", "italic");
        doc.setTextColor(156, 163, 175);
        doc.text("Sem apontamentos registrados.", margin + 6, y);
        y += 5;
      }

      y += 2;
    }

    y += 2;
    doc.setDrawColor(226, 232, 240);
    doc.setLineWidth(0.3);
    doc.line(margin, y, W - margin, y);
    y += 6;
  }

  // ── Signatures section ────────────────────────────────────────────────────
  const pg = addPageIfNeeded(doc, y, 70);
  y = pg.y;

  doc.setFontSize(10);
  doc.setFont("helvetica", "bold");
  doc.setTextColor(15, 23, 42);
  doc.text("Assinaturas de Aprovação", margin, y);
  y += 6;

  const sigBoxW = contentWidth / 3 - 3;
  const allTypes = ["executor", "area_responsible", "immediate_supervisor"];
  const sigsMap = Object.fromEntries(signatures.map((s) => [s.signerType, s]));

  allTypes.forEach((type, i) => {
    const sig = sigsMap[type];
    const boxX = margin + i * (sigBoxW + 4.5);
    const boxH = sig?.signatureData ? 58 : 46;

    doc.setDrawColor(203, 213, 225);
    doc.setLineWidth(0.4);
    doc.roundedRect(boxX, y, sigBoxW, boxH, 2, 2, "S");

    doc.setFontSize(7);
    doc.setFont("helvetica", "bold");
    doc.setTextColor(100, 116, 139);
    doc.text(SIGNER_LABELS[type] || type, boxX + 3, y + 6);

    if (sig) {
      if (sig.signatureData) {
        try {
          doc.addImage(sig.signatureData, "PNG", boxX + 3, y + 9, sigBoxW - 6, 28);
        } catch {}
      }

      doc.setFontSize(7.5);
      doc.setFont("helvetica", "bold");
      doc.setTextColor(15, 23, 42);
      const nameY = sig.signatureData ? y + 41 : y + 16;
      const nameText = sig.signerName.length > 22 ? sig.signerName.slice(0, 19) + "..." : sig.signerName;
      doc.text(nameText, boxX + 3, nameY);

      if (sig.signerMatricula) {
        doc.setFontSize(7);
        doc.setFont("helvetica", "normal");
        doc.setTextColor(100, 116, 139);
        doc.text(`Matrícula: ${sig.signerMatricula}`, boxX + 3, nameY + 5);
      }

      doc.setFontSize(6.5);
      doc.setTextColor(100, 116, 139);
      const dateStr = sig.signedAt ? new Date(sig.signedAt).toLocaleString("pt-BR") : "";
      const dateY = sig.signerMatricula ? nameY + 10 : nameY + 5;
      doc.text(dateStr, boxX + 3, dateY);
    } else {
      doc.setFontSize(7);
      doc.setFont("helvetica", "italic");
      doc.setTextColor(156, 163, 175);
      doc.text("Aguardando assinatura", boxX + 3, y + 22);
      doc.setDrawColor(203, 213, 225);
      doc.line(boxX + 3, y + 32, boxX + sigBoxW - 3, y + 32);
      doc.setFontSize(6);
      doc.setFont("helvetica", "normal");
      doc.setTextColor(156, 163, 175);
      doc.text("Assinatura / Data", boxX + 3, y + 37);
    }
  });

  y += 66;

  // ── Footer ─────────────────────────────────────────────────────────────────
  const pageCount = doc.getNumberOfPages();
  for (let p = 1; p <= pageCount; p++) {
    doc.setPage(p);
    doc.setFontSize(7);
    doc.setFont("helvetica", "normal");
    doc.setTextColor(148, 163, 184);
    doc.text(`GeoLab – Sistema de Apontamento de Manutenção  |  Página ${p}/${pageCount}`, margin, 290);
    doc.text(`OS ${order.orderNumber}`, W - margin, 290, { align: "right" });
  }

  doc.save(`OS_${order.orderNumber}.pdf`);
}
