import { Route, Redirect } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { ReactNode } from "react";

interface PrivateRouteProps {
  path: string;
  component?: React.ComponentType<any>;
  children?: ReactNode;
  requireAdmin?: boolean;
}

export function PrivateRoute({ path, component: Component, children, requireAdmin = false }: PrivateRouteProps) {
  const { isAuthenticated, isAdmin } = useAuth();

  return (
    <Route path={path}>
      {(params) => {
        if (!isAuthenticated) {
          return <Redirect to="/" />;
        }

        if (requireAdmin && !isAdmin) {
          return <Redirect to="/user" />;
        }
        
        if (!requireAdmin && isAdmin) {
          return <Redirect to="/admin" />;
        }

        if (Component) {
          return <Component {...params} />;
        }

        return <>{children}</>;
      }}
    </Route>
  );
}
