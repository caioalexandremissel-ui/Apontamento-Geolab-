import { useRef, useState } from "react";
import SignaturePad, { SignaturePadHandle } from "./SignaturePad";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { X, RotateCcw, Check } from "lucide-react";

interface SignatureModalProps {
  title: string;
  defaultName?: string;
  defaultMatricula?: string;
  onSave: (data: { signerName: string; signerMatricula: string; signatureData: string }) => void;
  onClose: () => void;
  isSaving?: boolean;
}

export default function SignatureModal({
  title,
  defaultName = "",
  defaultMatricula = "",
  onSave,
  onClose,
  isSaving = false,
}: SignatureModalProps) {
  const padRef = useRef<SignaturePadHandle>(null);
  const [signerName, setSignerName] = useState(defaultName);
  const [signerMatricula, setSignerMatricula] = useState(defaultMatricula);
  const [error, setError] = useState("");

  const handleSave = () => {
    if (!signerName.trim()) {
      setError("Informe o nome do assinante.");
      return;
    }
    if (padRef.current?.isEmpty()) {
      setError("Por favor, assine no campo abaixo antes de confirmar.");
      return;
    }
    setError("");
    const signatureData = padRef.current!.getDataURL();
    onSave({ signerName: signerName.trim(), signerMatricula: signerMatricula.trim(), signatureData });
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
      <div className="bg-card border border-border rounded-xl w-full max-w-lg shadow-2xl">
        <div className="flex items-center justify-between p-5 border-b border-border">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="text-muted-foreground hover:text-foreground">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <Label htmlFor="signer-name">Nome *</Label>
              <Input
                id="signer-name"
                value={signerName}
                onChange={(e) => setSignerName(e.target.value)}
                placeholder="Nome completo"
              />
            </div>
            <div className="space-y-1">
              <Label htmlFor="signer-mat">Matrícula</Label>
              <Input
                id="signer-mat"
                value={signerMatricula}
                onChange={(e) => setSignerMatricula(e.target.value)}
                placeholder="Opcional"
              />
            </div>
          </div>

          <div className="space-y-1">
            <div className="flex items-center justify-between">
              <Label>Assinatura *</Label>
              <button
                onClick={() => padRef.current?.clear()}
                className="text-xs text-muted-foreground hover:text-foreground flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                Limpar
              </button>
            </div>
            <div className="rounded-lg overflow-hidden border border-border">
              <SignaturePad ref={padRef} height={160} />
            </div>
            <p className="text-xs text-muted-foreground">Assine com o mouse ou o dedo (toque)</p>
          </div>

          {error && <p className="text-sm text-red-400">{error}</p>}
        </div>

        <div className="flex items-center justify-end gap-3 p-5 border-t border-border">
          <Button variant="ghost" onClick={onClose}>
            Cancelar
          </Button>
          <Button onClick={handleSave} disabled={isSaving}>
            <Check className="w-4 h-4 mr-2" />
            {isSaving ? "Salvando..." : "Confirmar Assinatura"}
          </Button>
        </div>
      </div>
    </div>
  );
}
