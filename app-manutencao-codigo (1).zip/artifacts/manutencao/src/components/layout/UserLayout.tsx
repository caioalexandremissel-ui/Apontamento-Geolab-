import { ReactNode } from "react";
import { Link, useLocation } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useLogout } from "@workspace/api-client-react";
import { FileText, LogOut, Activity, Bell } from "lucide-react";

export function UserLayout({ children }: { children: ReactNode }) {
  const { user, logout } = useAuth();
  const logoutMutation = useLogout();
  const [location] = useLocation();

  const handleLogout = () => {
    logoutMutation.mutate(undefined, {
      onSuccess: () => {
        logout();
      },
      onError: () => {
        logout(); // Fallback if API fails
      }
    });
  };

  const navItems = [
    { href: "/user", label: "Minhas Ordens", icon: FileText },
    { href: "/user/solicitacoes", label: "Minhas Solicitações", icon: Bell },
  ];

  return (
    <div className="min-h-screen bg-background flex flex-col">
      <header className="bg-card border-b border-border">
        <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2 text-primary font-bold text-lg">
            <Activity className="w-6 h-6" />
            <span className="hidden sm:inline">GeoLab Manutenção</span>
            <span className="sm:hidden">GeoLab</span>
          </div>

          <nav className="flex items-center gap-1 sm:gap-4">
            {navItems.map((item) => {
              const isActive = location === item.href || (location.startsWith(item.href) && item.href !== "/user");
              const Icon = item.icon;
              return (
                <Link 
                  key={item.href} 
                  href={item.href}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive 
                      ? "bg-primary text-primary-foreground" 
                      : "text-muted-foreground hover:bg-secondary hover:text-foreground"
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{item.label}</span>
                </Link>
              );
            })}
          </nav>

          <div className="flex items-center gap-4">
            <div className="hidden sm:block text-right">
              <div className="text-sm font-medium text-foreground">{user?.name}</div>
              <div className="text-xs text-muted-foreground">{user?.matricula}</div>
            </div>
            <button 
              onClick={handleLogout}
              className="p-2 text-muted-foreground hover:text-destructive hover:bg-secondary rounded-md transition-colors"
              title="Sair"
            >
              <LogOut className="w-5 h-5" />
            </button>
          </div>
        </div>
      </header>

      <main className="flex-1 bg-background">
        <div className="max-w-7xl mx-auto p-4 py-8">
          {children}
        </div>
      </main>
    </div>
  );
}
