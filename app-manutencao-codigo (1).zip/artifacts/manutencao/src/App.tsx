import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/contexts/AuthContext";
import { PrivateRoute } from "@/components/PrivateRoute";

import Login from "@/pages/login";
import Register from "@/pages/register";
import AdminDashboard from "@/pages/admin/dashboard";
import AdminOrders from "@/pages/admin/orders";
import AdminUsers from "@/pages/admin/users";
import AdminRequests from "@/pages/admin/requests";
import AdminCodes from "@/pages/admin/codes";
import AdminExport from "@/pages/admin/export";
import AdminOrderDetail from "@/pages/admin/order-detail";
import UserHome from "@/pages/user/home";
import UserRequests from "@/pages/user/requests";
import UserOrderDetail from "@/pages/user/order-detail";
import UserAppointmentForm from "@/pages/user/appointment-form";
import NotFound from "@/pages/not-found";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      retry: 1,
      refetchOnWindowFocus: false,
    },
  },
});

function Router() {
  return (
    <Switch>
      <Route path="/" component={Login} />
      <Route path="/cadastro" component={Register} />
      
      {/* Admin Routes */}
      <PrivateRoute path="/admin" component={AdminDashboard} requireAdmin />
      <PrivateRoute path="/admin/ordens" component={AdminOrders} requireAdmin />
      <PrivateRoute path="/admin/ordens/:id" component={AdminOrderDetail} requireAdmin />
      <PrivateRoute path="/admin/colaboradores" component={AdminUsers} requireAdmin />
      <PrivateRoute path="/admin/solicitacoes" component={AdminRequests} requireAdmin />
      <PrivateRoute path="/admin/codigos" component={AdminCodes} requireAdmin />
      <PrivateRoute path="/admin/exportar" component={AdminExport} requireAdmin />

      {/* User Routes */}
      <PrivateRoute path="/user" component={UserHome} />
      <PrivateRoute path="/user/solicitacoes" component={UserRequests} />
      <PrivateRoute path="/user/ordens/:id" component={UserOrderDetail} />
      <PrivateRoute path="/user/ordens/:id/linhas/:lineId" component={UserAppointmentForm} />

      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <Router />
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
