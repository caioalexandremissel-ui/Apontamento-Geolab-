import { AdminLayout } from "@/components/layout/AdminLayout";
import {
  useListServiceOrders,
  getListServiceOrdersQueryKey,
  useImportServiceOrders,
  ServiceOrderInputType,
} from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Link, useLocation } from "wouter";
import { Plus, Search, Upload, CheckCircle, AlertCircle, X } from "lucide-react";
import { useState, useRef } from "react";
import { useQueryClient } from "@tanstack/react-query";
import * as XLSX from "xlsx";

interface ImportResult {
  imported: number;
  skipped: number;
  errors: string[];
}

export default function AdminOrders() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");
  const [typeFilter, setTypeFilter] = useState("all");
  const [importResult, setImportResult] = useState<ImportResult | null>(null);
  const [importError, setImportError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const { data: orders, isLoading } = useListServiceOrders({
    status: statusFilter !== "all" ? statusFilter : undefined,
    type: typeFilter !== "all" ? typeFilter : undefined,
  });

  const { mutate: importOrders, isPending: isImporting } = useImportServiceOrders({
    mutation: {
      onSuccess: (result) => {
        setImportResult(result);
        queryClient.invalidateQueries({ queryKey: getListServiceOrdersQueryKey() });
      },
      onError: () => {
        setImportError("Erro ao importar. Verifique o formato do arquivo.");
      },
    },
  });

  const handleImportClick = () => {
    setImportResult(null);
    setImportError(null);
    fileInputRef.current?.click();
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (evt) => {
      try {
        const data = new Uint8Array(evt.target?.result as ArrayBuffer);
        const workbook = XLSX.read(data, { type: "array" });
        const sheet = workbook.Sheets[workbook.SheetNames[0]];
        const rows: any[] = XLSX.utils.sheet_to_json(sheet, { defval: "" });

        const orders = rows.map((row) => ({
          orderNumber: String(row["Ordem"] || row["orderNumber"] || row["Numero"] || row["N Ordem"] || "").trim(),
          description: String(row["Descricao"] || row["Descrição"] || row["description"] || row["Desc"] || "").trim(),
          type: (String(row["Tipo"] || row["type"] || "preventive").toLowerCase().includes("corr") ? ServiceOrderInputType.corrective : ServiceOrderInputType.preventive),
          status: "open",
          equipment: String(row["Equipamento"] || row["equipment"] || "").trim() || undefined,
          costCenter: String(row["Centro Custo"] || row["CentroCusto"] || row["costCenter"] || row["C.Custo"] || "").trim() || undefined,
          location: String(row["Local"] || row["Localização"] || row["location"] || "").trim() || undefined,
          expectedDuration: row["Duracao"] || row["Duração"] || row["expectedDuration"] || undefined,
          openDate: String(row["Data Abertura"] || row["DataAbertura"] || row["openDate"] || "").trim() || undefined,
          center: String(row["Centro"] || row["center"] || "").trim() || undefined,
          area: String(row["Area"] || row["Área"] || row["area"] || "").trim() || undefined,
          activityType: String(row["Tipo Atividade"] || row["TipoAtividade"] || row["activityType"] || "").trim() || undefined,
        })).filter((o) => o.orderNumber && o.description);

        if (orders.length === 0) {
          setImportError("Nenhuma linha válida encontrada. Verifique as colunas: Ordem, Descrição.");
          return;
        }

        importOrders({ data: { orders } });
      } catch {
        setImportError("Erro ao ler o arquivo. Certifique-se de que é um Excel (.xlsx ou .xls).");
      }
    };
    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  const filteredOrders = orders?.filter(
    (os) =>
      os.orderNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      os.description.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <AdminLayout>
      <input
        ref={fileInputRef}
        type="file"
        accept=".xlsx,.xls"
        className="hidden"
        onChange={handleFileChange}
      />

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Ordens de Serviço</h1>
          <p className="text-muted-foreground">Gerencie todas as OS do sistema.</p>
        </div>

        <div className="flex items-center gap-2 w-full md:w-auto">
          <Button variant="outline" onClick={handleImportClick} disabled={isImporting}>
            <Upload className="w-4 h-4 mr-2" />
            {isImporting ? "Importando..." : "Importar Excel"}
          </Button>
          <Button onClick={() => setLocation("/admin/ordens/nova")}>
            <Plus className="w-4 h-4 mr-2" />
            Nova OS
          </Button>
        </div>
      </div>

      {importResult && (
        <div className="mb-4 p-4 rounded-lg border border-green-500/30 bg-green-500/10 flex items-start gap-3">
          <CheckCircle className="w-5 h-5 text-green-400 mt-0.5 shrink-0" />
          <div className="flex-1">
            <p className="font-medium text-green-400">Importação concluída</p>
            <p className="text-sm text-muted-foreground">
              {importResult.imported} importadas, {importResult.skipped} ignoradas (já existiam)
              {importResult.errors.length > 0 && `, ${importResult.errors.length} erros`}
            </p>
          </div>
          <button onClick={() => setImportResult(null)}>
            <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
          </button>
        </div>
      )}

      {importError && (
        <div className="mb-4 p-4 rounded-lg border border-red-500/30 bg-red-500/10 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-red-400 mt-0.5 shrink-0" />
          <div className="flex-1">
            <p className="font-medium text-red-400">Erro na importação</p>
            <p className="text-sm text-muted-foreground">{importError}</p>
          </div>
          <button onClick={() => setImportError(null)}>
            <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
          </button>
        </div>
      )}

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="p-4 border-b border-border flex flex-col md:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por número ou descrição..."
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
          <div className="flex gap-2">
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Tipo" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Tipos</SelectItem>
                <SelectItem value="preventive">Preventiva</SelectItem>
                <SelectItem value="corrective">Corretiva</SelectItem>
              </SelectContent>
            </Select>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[150px]">
                <SelectValue placeholder="Status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos Status</SelectItem>
                <SelectItem value="open">Aberta</SelectItem>
                <SelectItem value="in_progress">Em Andamento</SelectItem>
                <SelectItem value="completed">Concluída</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {isLoading ? (
          <div className="p-4 space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Número</TableHead>
                  <TableHead>Descrição</TableHead>
                  <TableHead>Tipo</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Equipamento</TableHead>
                  <TableHead className="text-right">Linhas</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredOrders && filteredOrders.length > 0 ? (
                  filteredOrders.map((os) => (
                    <TableRow
                      key={os.id}
                      className="cursor-pointer hover:bg-secondary/50"
                      onClick={() => setLocation(`/admin/ordens/${os.id}`)}
                    >
                      <TableCell className="font-mono font-medium text-primary">{os.orderNumber}</TableCell>
                      <TableCell className="max-w-[250px] truncate">{os.description}</TableCell>
                      <TableCell>
                        <Badge
                          variant="outline"
                          className={
                            os.type === "preventive"
                              ? "text-blue-400 border-blue-400/20"
                              : "text-amber-500 border-amber-500/20"
                          }
                        >
                          {os.type === "preventive" ? "Preventiva" : "Corretiva"}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          variant={
                            os.status === "in_progress"
                              ? "default"
                              : os.status === "completed"
                              ? "secondary"
                              : "outline"
                          }
                        >
                          {os.status === "open"
                            ? "Aberta"
                            : os.status === "in_progress"
                            ? "Em Andamento"
                            : "Concluída"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-muted-foreground">{os.equipment || "-"}</TableCell>
                      <TableCell className="text-right font-medium">{os.lines?.length || 0}</TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      Nenhuma ordem de serviço encontrada.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </div>

      <div className="mt-4 p-3 rounded border border-border bg-secondary/20 text-xs text-muted-foreground">
        <strong>Formato esperado do Excel:</strong> colunas <code>Ordem</code>, <code>Descrição</code> (obrigatórias) e opcionalmente: <code>Tipo</code> (Preventiva/Corretiva), <code>Equipamento</code>, <code>Centro Custo</code>, <code>Local</code>, <code>Duração</code>, <code>Data Abertura</code>.
      </div>
    </AdminLayout>
  );
}
