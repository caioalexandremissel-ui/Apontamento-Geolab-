import { AdminLayout } from "@/components/layout/AdminLayout";
import {
  useListUsers,
  getListUsersQueryKey,
  useUpdateUser,
  useCreateUser,
} from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Skeleton } from "@/components/ui/skeleton";
import { Switch } from "@/components/ui/switch";
import { Plus, Search, ShieldAlert, User as UserIcon, X } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";

interface CreateForm {
  name: string;
  matricula: string;
  centTrab: string;
}

export default function AdminUsers() {
  const [searchTerm, setSearchTerm] = useState("");
  const [showModal, setShowModal] = useState(false);
  const [form, setForm] = useState<CreateForm>({ name: "", matricula: "", centTrab: "" });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const { data: users, isLoading } = useListUsers();
  const updateUserMutation = useUpdateUser();
  const createUserMutation = useCreateUser();

  const toggleStatus = (id: number, active: boolean) => {
    updateUserMutation.mutate(
      { id, data: { active } },
      {
        onSuccess: () => {
          toast({ title: "Status atualizado", description: `Usuário ${active ? "ativado" : "desativado"}.` });
          queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
        },
        onError: () => {
          toast({ title: "Erro", description: "Não foi possível atualizar o status.", variant: "destructive" });
        },
      }
    );
  };

  const handleCreate = () => {
    if (!form.name.trim() || !form.matricula.trim()) {
      toast({ title: "Campos obrigatórios", description: "Nome e matrícula são obrigatórios.", variant: "destructive" });
      return;
    }
    createUserMutation.mutate(
      {
        data: {
          name: form.name.trim(),
          matricula: form.matricula.trim(),
          centTrab: form.centTrab.trim() || undefined,
          role: "user",
          active: true,
        },
      },
      {
        onSuccess: () => {
          toast({
            title: "Colaborador criado",
            description: `${form.name} adicionado. Senha inicial: ${form.matricula}`,
          });
          queryClient.invalidateQueries({ queryKey: getListUsersQueryKey() });
          setShowModal(false);
          setForm({ name: "", matricula: "", centTrab: "" });
        },
        onError: (err: any) => {
          const msg = err?.response?.data?.error || "Não foi possível criar o colaborador.";
          toast({ title: "Erro", description: msg, variant: "destructive" });
        },
      }
    );
  };

  const filteredUsers = users?.filter(
    (u) =>
      u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      u.matricula.includes(searchTerm)
  );

  return (
    <AdminLayout>
      {/* Create modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 p-4">
          <div className="bg-card border border-border rounded-xl w-full max-w-md shadow-2xl">
            <div className="flex items-center justify-between p-5 border-b border-border">
              <h2 className="text-lg font-bold">Novo Colaborador</h2>
              <button onClick={() => setShowModal(false)} className="text-muted-foreground hover:text-foreground">
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="p-5 space-y-4">
              <div className="space-y-1">
                <Label htmlFor="new-name">Nome Completo *</Label>
                <Input
                  id="new-name"
                  value={form.name}
                  onChange={(e) => setForm((f) => ({ ...f, name: e.target.value }))}
                  placeholder="Ex: João da Silva"
                />
              </div>
              <div className="space-y-1">
                <Label htmlFor="new-mat">Matrícula *</Label>
                <Input
                  id="new-mat"
                  value={form.matricula}
                  onChange={(e) => setForm((f) => ({ ...f, matricula: e.target.value }))}
                  placeholder="Ex: 12345"
                />
                <p className="text-xs text-muted-foreground">A senha inicial será a própria matrícula.</p>
              </div>
              <div className="space-y-1">
                <Label htmlFor="new-ct">Centro de Trabalho (Opcional)</Label>
                <Input
                  id="new-ct"
                  value={form.centTrab}
                  onChange={(e) => setForm((f) => ({ ...f, centTrab: e.target.value }))}
                  placeholder="Ex: MEC_UTI"
                />
              </div>
            </div>
            <div className="flex gap-3 p-5 border-t border-border">
              <Button variant="ghost" className="flex-1" onClick={() => setShowModal(false)}>
                Cancelar
              </Button>
              <Button className="flex-1" onClick={handleCreate} disabled={createUserMutation.isPending}>
                {createUserMutation.isPending ? "Criando..." : "Criar Colaborador"}
              </Button>
            </div>
          </div>
        </div>
      )}

      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Colaboradores</h1>
          <p className="text-muted-foreground">Gerencie acessos e perfis da equipe.</p>
        </div>
        <Button onClick={() => setShowModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Novo Colaborador
        </Button>
      </div>

      <div className="bg-card border border-border rounded-lg overflow-hidden">
        <div className="p-4 border-b border-border">
          <div className="relative max-w-sm">
            <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Buscar por nome ou matrícula..."
              className="pl-9"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
            />
          </div>
        </div>

        {isLoading ? (
          <div className="p-4 space-y-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-12 w-full" />
            ))}
          </div>
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Matrícula</TableHead>
                  <TableHead>Nome</TableHead>
                  <TableHead>Perfil</TableHead>
                  <TableHead>C. Trabalho</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-right">Senha Inicial</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filteredUsers && filteredUsers.length > 0 ? (
                  filteredUsers.map((u) => (
                    <TableRow key={u.id}>
                      <TableCell className="font-mono text-muted-foreground">{u.matricula}</TableCell>
                      <TableCell className="font-medium">
                        <div className="flex items-center gap-2">
                          <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center text-xs font-bold">
                            {u.name.charAt(0)}
                          </div>
                          {u.name}
                        </div>
                      </TableCell>
                      <TableCell>
                        {u.role === "admin" ? (
                          <Badge variant="default" className="bg-primary/20 text-primary border-primary/30">
                            <ShieldAlert className="w-3 h-3 mr-1" /> Admin
                          </Badge>
                        ) : (
                          <Badge variant="outline">
                            <UserIcon className="w-3 h-3 mr-1" /> Operador
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell className="text-muted-foreground">{u.centTrab || "-"}</TableCell>
                      <TableCell>
                        <Switch
                          checked={u.active}
                          onCheckedChange={(checked) => toggleStatus(u.id, checked)}
                          disabled={updateUserMutation.isPending}
                        />
                      </TableCell>
                      <TableCell className="text-right font-mono text-xs text-muted-foreground">
                        {u.matricula}
                      </TableCell>
                    </TableRow>
                  ))
                ) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                      Nenhum colaborador encontrado.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>
        )}
      </div>
    </AdminLayout>
  );
}
