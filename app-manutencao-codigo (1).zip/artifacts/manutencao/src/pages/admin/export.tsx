import { AdminLayout } from "@/components/layout/AdminLayout";
import { useExportConfirmations } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Download, FileSpreadsheet, Info } from "lucide-react";
import { useState } from "react";
import { useToast } from "@/hooks/use-toast";
import * as XLSX from "xlsx";

function toSapDate(iso: string): string {
  if (!iso) return "";
  const [y, m, d] = iso.split("-");
  if (!y || !m || !d) return iso;
  return `${d}.${m}.${y}`;
}

function toSapTime(time: string): string {
  if (!time) return "";
  return time.slice(0, 8);
}

function sapStatus(status: string): string {
  if (status === "finished" || status === "edited") return "Encerrada";
  return status;
}

export default function AdminExport() {
  const { toast } = useToast();
  const [startDate, setStartDate] = useState("");
  const [endDate, setEndDate] = useState("");
  const [matricula, setMatricula] = useState("");

  const { isLoading, refetch } = useExportConfirmations(
    { startDate: startDate || undefined, endDate: endDate || undefined, matricula: matricula || undefined },
    { query: { queryKey: ["/api/export/confirmations"], enabled: false } }
  );

  const handleExport = async () => {
    try {
      const { data } = await refetch();
      if (!data || !data.data || data.data.length === 0) {
        toast({ title: "Nenhum dado encontrado", description: "Ajuste os filtros e tente novamente." });
        return;
      }

      // Map to SAP column format
      const rows = data.data.map((row: {
        orderNumber: string;
        centTrab: string;
        center: string;
        activityType: string;
        employeeMatricula: string;
        startDate: string;
        startTime: string;
        endDate: string;
        endTime: string;
        observation: string;
        status: string;
      }) => ({
        "ORDEM": row.orderNumber,
        "CEN TRAP": row.centTrab,
        "CEN.": row.center,
        "TAtiv.": row.activityType,
        "N°Pessoal": row.employeeMatricula,
        "Inic.Exec.": toSapDate(row.startDate),
        "hora.Exec.": toSapTime(row.startTime),
        "Fim.Exec.": toSapDate(row.endDate),
        "Fim.Ex.": toSapTime(row.endTime),
        "Texto de Confirmação": row.observation,
        "Status": sapStatus(row.status),
      }));

      const worksheet = XLSX.utils.json_to_sheet(rows);

      // Set column widths
      worksheet["!cols"] = [
        { wch: 12 }, // ORDEM
        { wch: 12 }, // CEN TRAP
        { wch: 8 },  // CEN.
        { wch: 10 }, // TAtiv.
        { wch: 12 }, // N°Pessoal
        { wch: 12 }, // Inic.Exec.
        { wch: 10 }, // hora.Exec.
        { wch: 12 }, // Fim.Exec.
        { wch: 10 }, // Fim.Ex.
        { wch: 40 }, // Texto de Confirmação
        { wch: 12 }, // Status
      ];

      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Apontamentos");

      const fileName = `exportacao-sap-${new Date().toISOString().slice(0, 10)}.xlsx`;
      XLSX.writeFile(workbook, fileName);

      toast({ title: "Exportação concluída", description: `${data.count} registros exportados para ${fileName}.` });
    } catch {
      toast({ title: "Erro na exportação", description: "Ocorreu um erro ao gerar o arquivo.", variant: "destructive" });
    }
  };

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Exportar para SAP</h1>
        <p className="text-muted-foreground">Gere planilha no formato padrão SAP com os apontamentos finalizados.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileSpreadsheet className="w-5 h-5 text-primary" />
              Filtros de Exportação
            </CardTitle>
            <CardDescription>Apenas apontamentos com status <strong>Encerrada</strong> são incluídos.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label>Data Inicial</Label>
                <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
              </div>
              <div className="space-y-2">
                <Label>Data Final</Label>
                <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Matrícula do Operador (Opcional)</Label>
              <Input placeholder="Ex: 12654" value={matricula} onChange={e => setMatricula(e.target.value)} />
            </div>

            <Button className="w-full mt-4" onClick={handleExport} disabled={isLoading}>
              <Download className="w-4 h-4 mr-2" />
              {isLoading ? "Gerando..." : "Exportar Excel (formato SAP)"}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-secondary/30 border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Info className="w-4 h-4" />
              Colunas Geradas
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="text-xs w-full border-collapse">
                <thead>
                  <tr className="bg-muted">
                    {["ORDEM","CEN TRAP","CEN.","TAtiv.","N°Pessoal","Inic.Exec.","hora.Exec.","Fim.Exec.","Fim.Ex.","Texto de Confirmação","Status"].map(col => (
                      <th key={col} className="border border-border px-2 py-1 text-left font-semibold whitespace-nowrap">{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  <tr className="text-muted-foreground">
                    <td className="border border-border px-2 py-1 whitespace-nowrap">80372017</td>
                    <td className="border border-border px-2 py-1 whitespace-nowrap">MAN_INS</td>
                    <td className="border border-border px-2 py-1">0001</td>
                    <td className="border border-border px-2 py-1">MANUT2</td>
                    <td className="border border-border px-2 py-1">12654</td>
                    <td className="border border-border px-2 py-1 whitespace-nowrap">11.06.2026</td>
                    <td className="border border-border px-2 py-1 whitespace-nowrap">09:40:00</td>
                    <td className="border border-border px-2 py-1 whitespace-nowrap">11.06.2026</td>
                    <td className="border border-border px-2 py-1 whitespace-nowrap">10:00:00</td>
                    <td className="border border-border px-2 py-1">REALIZADO A CALIBRAÇÃO</td>
                    <td className="border border-border px-2 py-1">Encerrada</td>
                  </tr>
                </tbody>
              </table>
            </div>
            <p className="text-xs text-muted-foreground mt-3">Exemplo de linha exportada. Datas no formato <code>DD.MM.YYYY</code>.</p>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
