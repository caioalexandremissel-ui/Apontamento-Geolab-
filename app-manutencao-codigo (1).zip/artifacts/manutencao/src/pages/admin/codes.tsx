import { AdminLayout } from "@/components/layout/AdminLayout";
import {
  useListMaintenanceCodes,
  useListRootCauses,
  useCreateMaintenanceCode,
  useDeleteMaintenanceCode,
  useCreateRootCause,
  useDeleteRootCause,
  getListMaintenanceCodesQueryKey,
  getListRootCausesQueryKey,
  MaintenanceCodeInputType,
} from "@workspace/api-client-react";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Trash2, Upload, Download, CheckCircle2, AlertTriangle, X, FileSpreadsheet } from "lucide-react";
import { useRef, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { useQueryClient } from "@tanstack/react-query";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import * as XLSX from "xlsx";

const codeSchema = z.object({
  code: z.string().min(1, "Código obrigatório"),
  name: z.string().min(1, "Nome obrigatório"),
  type: z.enum([MaintenanceCodeInputType.preventive, MaintenanceCodeInputType.corrective]),
});

const rootCauseSchema = z.object({
  code: z.string().min(1, "Código obrigatório"),
  description: z.string().min(1, "Descrição obrigatória"),
});

type CodeRow = { code: string; name: string; type: "preventive" | "corrective"; _error?: string };
type CauseRow = { code: string; description: string; _error?: string };

function parseType(val: string): "preventive" | "corrective" {
  const v = String(val || "").toLowerCase().trim();
  if (v === "corretiva" || v === "corrective" || v === "c") return "corrective";
  return "preventive";
}

function downloadTemplate(type: "codes" | "causes") {
  const wb = XLSX.utils.book_new();
  if (type === "codes") {
    const ws = XLSX.utils.aoa_to_sheet([
      ["Código", "Nome", "Tipo"],
      ["PM01", "Inspeção Mensal", "Preventiva"],
      ["CM01", "Reparo Emergencial", "Corretiva"],
    ]);
    ws["!cols"] = [{ wch: 12 }, { wch: 30 }, { wch: 15 }];
    XLSX.utils.book_append_sheet(wb, ws, "Códigos de Manutenção");
    XLSX.writeFile(wb, "modelo_codigos_manutencao.xlsx");
  } else {
    const ws = XLSX.utils.aoa_to_sheet([
      ["Código", "Descrição"],
      ["C01", "Desgaste natural"],
      ["C02", "Falha de operação"],
    ]);
    ws["!cols"] = [{ wch: 12 }, { wch: 40 }];
    XLSX.utils.book_append_sheet(wb, ws, "Causas Raiz");
    XLSX.writeFile(wb, "modelo_causas_raiz.xlsx");
  }
}

function parseCodesFile(file: File): Promise<CodeRow[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<any>(ws, { defval: "" });
        const parsed: CodeRow[] = rows.map((r: any) => {
          const code = String(r["Código"] || r["Codigo"] || r["code"] || "").trim();
          const name = String(r["Nome"] || r["name"] || "").trim();
          const type = parseType(r["Tipo"] || r["type"] || "Preventiva");
          const _error = !code ? "Código vazio" : !name ? "Nome vazio" : undefined;
          return { code, name, type, _error };
        });
        resolve(parsed);
      } catch (err) {
        reject(err);
      }
    };
    reader.readAsArrayBuffer(file);
  });
}

function parseCausesFile(file: File): Promise<CauseRow[]> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = new Uint8Array(e.target?.result as ArrayBuffer);
        const wb = XLSX.read(data, { type: "array" });
        const ws = wb.Sheets[wb.SheetNames[0]];
        const rows = XLSX.utils.sheet_to_json<any>(ws, { defval: "" });
        const parsed: CauseRow[] = rows.map((r: any) => {
          const code = String(r["Código"] || r["Codigo"] || r["code"] || "").trim();
          const description = String(r["Descrição"] || r["Descricao"] || r["description"] || "").trim();
          const _error = !code ? "Código vazio" : !description ? "Descrição vazia" : undefined;
          return { code, description, _error };
        });
        resolve(parsed);
      } catch (err) {
        reject(err);
      }
    };
    reader.readAsArrayBuffer(file);
  });
}

interface ImportResult { imported: number; errors: number }

export default function AdminCodes() {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [isCodeDialogOpen, setIsCodeDialogOpen] = useState(false);
  const [isCauseDialogOpen, setIsCauseDialogOpen] = useState(false);

  const [codeImportRows, setCodeImportRows] = useState<CodeRow[] | null>(null);
  const [causeImportRows, setCauseImportRows] = useState<CauseRow[] | null>(null);
  const [importingCodes, setImportingCodes] = useState(false);
  const [importingCauses, setImportingCauses] = useState(false);
  const [codeImportResult, setCodeImportResult] = useState<ImportResult | null>(null);
  const [causeImportResult, setCauseImportResult] = useState<ImportResult | null>(null);

  const codeFileRef = useRef<HTMLInputElement>(null);
  const causeFileRef = useRef<HTMLInputElement>(null);

  const { data: codes, isLoading: loadingCodes } = useListMaintenanceCodes();
  const { data: causes, isLoading: loadingCauses } = useListRootCauses();

  const createCodeMutation = useCreateMaintenanceCode();
  const deleteCodeMutation = useDeleteMaintenanceCode();
  const createCauseMutation = useCreateRootCause();
  const deleteCauseMutation = useDeleteRootCause();

  const codeForm = useForm<z.infer<typeof codeSchema>>({
    resolver: zodResolver(codeSchema),
    defaultValues: { code: "", name: "", type: MaintenanceCodeInputType.preventive },
  });

  const causeForm = useForm<z.infer<typeof rootCauseSchema>>({
    resolver: zodResolver(rootCauseSchema),
    defaultValues: { code: "", description: "" },
  });

  const onCodeSubmit = (data: z.infer<typeof codeSchema>) => {
    createCodeMutation.mutate(
      { data },
      {
        onSuccess: () => {
          toast({ title: "Código criado com sucesso" });
          setIsCodeDialogOpen(false);
          codeForm.reset();
          queryClient.invalidateQueries({ queryKey: getListMaintenanceCodesQueryKey() });
        },
        onError: () => toast({ title: "Erro", description: "Não foi possível criar o código.", variant: "destructive" }),
      }
    );
  };

  const onCauseSubmit = (data: z.infer<typeof rootCauseSchema>) => {
    createCauseMutation.mutate(
      { data },
      {
        onSuccess: () => {
          toast({ title: "Causa raiz criada com sucesso" });
          setIsCauseDialogOpen(false);
          causeForm.reset();
          queryClient.invalidateQueries({ queryKey: getListRootCausesQueryKey() });
        },
        onError: () => toast({ title: "Erro", description: "Não foi possível criar a causa raiz.", variant: "destructive" }),
      }
    );
  };

  const handleDeleteCode = (id: number) => {
    deleteCodeMutation.mutate(
      { id },
      {
        onSuccess: () => {
          toast({ title: "Código removido" });
          queryClient.invalidateQueries({ queryKey: getListMaintenanceCodesQueryKey() });
        },
      }
    );
  };

  const handleDeleteCause = (id: number) => {
    deleteCauseMutation.mutate(
      { id },
      {
        onSuccess: () => {
          toast({ title: "Causa raiz removida" });
          queryClient.invalidateQueries({ queryKey: getListRootCausesQueryKey() });
        },
      }
    );
  };

  const handleCodeFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const rows = await parseCodesFile(file);
      setCodeImportRows(rows);
      setCodeImportResult(null);
    } catch {
      toast({ title: "Erro ao ler arquivo", description: "Verifique se o arquivo é um Excel válido.", variant: "destructive" });
    }
    e.target.value = "";
  };

  const handleCauseFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    try {
      const rows = await parseCausesFile(file);
      setCauseImportRows(rows);
      setCauseImportResult(null);
    } catch {
      toast({ title: "Erro ao ler arquivo", description: "Verifique se o arquivo é um Excel válido.", variant: "destructive" });
    }
    e.target.value = "";
  };

  const confirmCodeImport = async () => {
    if (!codeImportRows) return;
    setImportingCodes(true);
    const validRows = codeImportRows.filter((r) => !r._error);
    let imported = 0;
    let errors = 0;
    for (const row of validRows) {
      try {
        await new Promise<void>((resolve, reject) => {
          createCodeMutation.mutate(
            { data: { code: row.code, name: row.name, type: row.type } },
            { onSuccess: () => resolve(), onError: () => reject() }
          );
        });
        imported++;
      } catch {
        errors++;
      }
    }
    queryClient.invalidateQueries({ queryKey: getListMaintenanceCodesQueryKey() });
    setCodeImportResult({ imported, errors });
    setImportingCodes(false);
    toast({ title: `Importação concluída`, description: `${imported} código(s) importado(s)${errors > 0 ? `, ${errors} erro(s)` : ""}.` });
  };

  const confirmCauseImport = async () => {
    if (!causeImportRows) return;
    setImportingCauses(true);
    const validRows = causeImportRows.filter((r) => !r._error);
    let imported = 0;
    let errors = 0;
    for (const row of validRows) {
      try {
        await new Promise<void>((resolve, reject) => {
          createCauseMutation.mutate(
            { data: { code: row.code, description: row.description } },
            { onSuccess: () => resolve(), onError: () => reject() }
          );
        });
        imported++;
      } catch {
        errors++;
      }
    }
    queryClient.invalidateQueries({ queryKey: getListRootCausesQueryKey() });
    setCauseImportResult({ imported, errors });
    setImportingCauses(false);
    toast({ title: `Importação concluída`, description: `${imported} causa(s) importada(s)${errors > 0 ? `, ${errors} erro(s)` : ""}.` });
  };

  return (
    <AdminLayout>
      {/* Hidden file inputs */}
      <input ref={codeFileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleCodeFileChange} />
      <input ref={causeFileRef} type="file" accept=".xlsx,.xls,.csv" className="hidden" onChange={handleCauseFileChange} />

      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Catálogo de Códigos</h1>
        <p className="text-muted-foreground">Gerencie os códigos de manutenção e causas raiz.</p>
      </div>

      <Tabs defaultValue="codes" className="w-full">
        <TabsList className="grid w-full max-w-md grid-cols-2">
          <TabsTrigger value="codes">Códigos de Manutenção</TabsTrigger>
          <TabsTrigger value="causes">Causas Raiz</TabsTrigger>
        </TabsList>

        {/* ===== CÓDIGOS DE MANUTENÇÃO ===== */}
        <TabsContent value="codes" className="mt-6 space-y-4">
          <div className="flex flex-wrap justify-between gap-3 items-center">
            <h2 className="text-lg font-semibold">Lista de Códigos</h2>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={() => downloadTemplate("codes")}>
                <Download className="w-4 h-4 mr-2" /> Baixar Modelo
              </Button>
              <Button variant="outline" size="sm" onClick={() => codeFileRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" /> Importar Excel
              </Button>
              <Dialog open={isCodeDialogOpen} onOpenChange={setIsCodeDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm"><Plus className="w-4 h-4 mr-2" /> Novo Código</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Novo Código de Manutenção</DialogTitle></DialogHeader>
                  <Form {...codeForm}>
                    <form onSubmit={codeForm.handleSubmit(onCodeSubmit)} className="space-y-4">
                      <FormField control={codeForm.control} name="code" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Código SAP</FormLabel>
                          <FormControl><Input placeholder="Ex: PM01" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={codeForm.control} name="name" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Nome/Descrição</FormLabel>
                          <FormControl><Input placeholder="Ex: Inspeção Mensal" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={codeForm.control} name="type" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Tipo</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger><SelectValue /></SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="preventive">Preventiva</SelectItem>
                              <SelectItem value="corrective">Corretiva</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setIsCodeDialogOpen(false)}>Cancelar</Button>
                        <Button type="submit" disabled={createCodeMutation.isPending}>Salvar</Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Import preview for codes */}
          {codeImportRows && (
            <div className="rounded-xl border border-border bg-card p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-primary" />
                  <span className="font-semibold">Pré-visualização da importação</span>
                  <Badge variant="outline">{codeImportRows.length} linha(s)</Badge>
                  {codeImportRows.filter((r) => r._error).length > 0 && (
                    <Badge className="bg-destructive/20 text-destructive border-destructive/30">
                      {codeImportRows.filter((r) => r._error).length} erro(s)
                    </Badge>
                  )}
                </div>
                <button onClick={() => { setCodeImportRows(null); setCodeImportResult(null); }} className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {codeImportResult ? (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-green-500/10 border border-green-500/30">
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                  <span className="text-sm">
                    <strong>{codeImportResult.imported}</strong> importado(s)
                    {codeImportResult.errors > 0 && <>, <strong className="text-destructive">{codeImportResult.errors}</strong> erro(s)</>}
                  </span>
                </div>
              ) : (
                <>
                  <div className="rounded-lg border border-border overflow-auto max-h-52">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-8">#</TableHead>
                          <TableHead>Código</TableHead>
                          <TableHead>Nome</TableHead>
                          <TableHead>Tipo</TableHead>
                          <TableHead className="w-8"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {codeImportRows.map((r, i) => (
                          <TableRow key={i} className={r._error ? "bg-destructive/5" : ""}>
                            <TableCell className="text-muted-foreground text-xs">{i + 1}</TableCell>
                            <TableCell className="font-mono">{r.code || <span className="text-destructive italic">vazio</span>}</TableCell>
                            <TableCell>{r.name || <span className="text-destructive italic">vazio</span>}</TableCell>
                            <TableCell>{r.type === "preventive" ? "Preventiva" : "Corretiva"}</TableCell>
                            <TableCell>
                              {r._error
                                ? <AlertTriangle className="w-3.5 h-3.5 text-destructive" />
                                : <CheckCircle2 className="w-3.5 h-3.5 text-green-400" />}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex gap-2 justify-end">
                    <Button variant="ghost" size="sm" onClick={() => setCodeImportRows(null)}>Cancelar</Button>
                    <Button
                      size="sm"
                      disabled={importingCodes || codeImportRows.filter((r) => !r._error).length === 0}
                      onClick={confirmCodeImport}
                    >
                      {importingCodes
                        ? "Importando..."
                        : `Importar ${codeImportRows.filter((r) => !r._error).length} código(s)`}
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}

          <div className="bg-card border border-border rounded-lg overflow-hidden">
            {loadingCodes ? (
              <div className="p-4 space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Nome</TableHead>
                    <TableHead>Tipo</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {codes && codes.length > 0 ? codes.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-mono font-medium">{c.code}</TableCell>
                      <TableCell>{c.name}</TableCell>
                      <TableCell>
                        <Badge variant={c.type === "preventive" ? "outline" : "secondary"} className={c.type === "preventive" ? "text-blue-400 border-blue-400/30" : "text-amber-400 border-amber-400/30"}>
                          {c.type === "preventive" ? "Preventiva" : "Corretiva"}
                        </Badge>
                      </TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="text-destructive" onClick={() => handleDeleteCode(c.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  )) : (
                    <TableRow><TableCell colSpan={4} className="text-center py-6 text-muted-foreground">Nenhum código encontrado. Importe um Excel ou crie manualmente.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>

        {/* ===== CAUSAS RAIZ ===== */}
        <TabsContent value="causes" className="mt-6 space-y-4">
          <div className="flex flex-wrap justify-between gap-3 items-center">
            <h2 className="text-lg font-semibold">Lista de Causas Raiz</h2>
            <div className="flex gap-2 flex-wrap">
              <Button variant="outline" size="sm" onClick={() => downloadTemplate("causes")}>
                <Download className="w-4 h-4 mr-2" /> Baixar Modelo
              </Button>
              <Button variant="outline" size="sm" onClick={() => causeFileRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" /> Importar Excel
              </Button>
              <Dialog open={isCauseDialogOpen} onOpenChange={setIsCauseDialogOpen}>
                <DialogTrigger asChild>
                  <Button size="sm"><Plus className="w-4 h-4 mr-2" /> Nova Causa</Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader><DialogTitle>Nova Causa Raiz</DialogTitle></DialogHeader>
                  <Form {...causeForm}>
                    <form onSubmit={causeForm.handleSubmit(onCauseSubmit)} className="space-y-4">
                      <FormField control={causeForm.control} name="code" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Código</FormLabel>
                          <FormControl><Input placeholder="Ex: C01" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <FormField control={causeForm.control} name="description" render={({ field }) => (
                        <FormItem>
                          <FormLabel>Descrição</FormLabel>
                          <FormControl><Input placeholder="Ex: Desgaste natural" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )} />
                      <DialogFooter>
                        <Button type="button" variant="outline" onClick={() => setIsCauseDialogOpen(false)}>Cancelar</Button>
                        <Button type="submit" disabled={createCauseMutation.isPending}>Salvar</Button>
                      </DialogFooter>
                    </form>
                  </Form>
                </DialogContent>
              </Dialog>
            </div>
          </div>

          {/* Import preview for causes */}
          {causeImportRows && (
            <div className="rounded-xl border border-border bg-card p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <FileSpreadsheet className="w-5 h-5 text-primary" />
                  <span className="font-semibold">Pré-visualização da importação</span>
                  <Badge variant="outline">{causeImportRows.length} linha(s)</Badge>
                  {causeImportRows.filter((r) => r._error).length > 0 && (
                    <Badge className="bg-destructive/20 text-destructive border-destructive/30">
                      {causeImportRows.filter((r) => r._error).length} erro(s)
                    </Badge>
                  )}
                </div>
                <button onClick={() => { setCauseImportRows(null); setCauseImportResult(null); }} className="text-muted-foreground hover:text-foreground">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {causeImportResult ? (
                <div className="flex items-center gap-3 p-3 rounded-lg bg-green-500/10 border border-green-500/30">
                  <CheckCircle2 className="w-5 h-5 text-green-400" />
                  <span className="text-sm">
                    <strong>{causeImportResult.imported}</strong> importada(s)
                    {causeImportResult.errors > 0 && <>, <strong className="text-destructive">{causeImportResult.errors}</strong> erro(s)</>}
                  </span>
                </div>
              ) : (
                <>
                  <div className="rounded-lg border border-border overflow-auto max-h-52">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-8">#</TableHead>
                          <TableHead>Código</TableHead>
                          <TableHead>Descrição</TableHead>
                          <TableHead className="w-8"></TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {causeImportRows.map((r, i) => (
                          <TableRow key={i} className={r._error ? "bg-destructive/5" : ""}>
                            <TableCell className="text-muted-foreground text-xs">{i + 1}</TableCell>
                            <TableCell className="font-mono">{r.code || <span className="text-destructive italic">vazio</span>}</TableCell>
                            <TableCell>{r.description || <span className="text-destructive italic">vazio</span>}</TableCell>
                            <TableCell>
                              {r._error
                                ? <AlertTriangle className="w-3.5 h-3.5 text-destructive" />
                                : <CheckCircle2 className="w-3.5 h-3.5 text-green-400" />}
                            </TableCell>
                          </TableRow>
                        ))}
                      </TableBody>
                    </Table>
                  </div>
                  <div className="flex gap-2 justify-end">
                    <Button variant="ghost" size="sm" onClick={() => setCauseImportRows(null)}>Cancelar</Button>
                    <Button
                      size="sm"
                      disabled={importingCauses || causeImportRows.filter((r) => !r._error).length === 0}
                      onClick={confirmCauseImport}
                    >
                      {importingCauses
                        ? "Importando..."
                        : `Importar ${causeImportRows.filter((r) => !r._error).length} causa(s)`}
                    </Button>
                  </div>
                </>
              )}
            </div>
          )}

          <div className="bg-card border border-border rounded-lg overflow-hidden">
            {loadingCauses ? (
              <div className="p-4 space-y-3">{[...Array(3)].map((_, i) => <Skeleton key={i} className="h-10 w-full" />)}</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Código</TableHead>
                    <TableHead>Descrição</TableHead>
                    <TableHead className="text-right">Ações</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {causes && causes.length > 0 ? causes.map((c) => (
                    <TableRow key={c.id}>
                      <TableCell className="font-mono font-medium">{c.code}</TableCell>
                      <TableCell>{c.description}</TableCell>
                      <TableCell className="text-right">
                        <Button variant="ghost" size="sm" className="text-destructive" onClick={() => handleDeleteCause(c.id)}>
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </TableCell>
                    </TableRow>
                  )) : (
                    <TableRow><TableCell colSpan={3} className="text-center py-6 text-muted-foreground">Nenhuma causa encontrada. Importe um Excel ou crie manualmente.</TableCell></TableRow>
                  )}
                </TableBody>
              </Table>
            )}
          </div>
        </TabsContent>
      </Tabs>
    </AdminLayout>
  );
}
