import { AdminLayout } from "@/components/layout/AdminLayout";
import { 
  useListEditRequests, 
  getListEditRequestsQueryKey,
  useUpdateEditRequest,
  EditRequestUpdateStatus
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { CheckCircle, XCircle, Clock, Search } from "lucide-react";
import { format } from "date-fns";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/contexts/AuthContext";
import { useQueryClient } from "@tanstack/react-query";
import { Input } from "@/components/ui/input";
import { useState } from "react";

export default function AdminRequests() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [searchTerm, setSearchTerm] = useState("");

  const { data: requests, isLoading } = useListEditRequests({ status: "pending" });

  const updateRequestMutation = useUpdateEditRequest();

  const handleAction = (id: number, status: EditRequestUpdateStatus) => {
    updateRequestMutation.mutate(
      { 
        id, 
        data: { 
          status,
          approvedBy: user?.name
        } 
      },
      {
        onSuccess: () => {
          toast({ 
            title: status === EditRequestUpdateStatus.approved ? "Solicitação Aprovada" : "Solicitação Rejeitada",
            description: "O status foi atualizado com sucesso." 
          });
          queryClient.invalidateQueries({ queryKey: getListEditRequestsQueryKey() });
        },
        onError: () => {
          toast({ title: "Erro", description: "Falha ao processar solicitação.", variant: "destructive" });
        }
      }
    );
  };

  const filteredRequests = requests?.filter(req => 
    req.requestedByName?.toLowerCase().includes(searchTerm.toLowerCase()) || 
    req.requestedBy.includes(searchTerm)
  );

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Solicitações de Edição</h1>
        <p className="text-muted-foreground">Aprove ou rejeite pedidos de alteração em apontamentos.</p>
      </div>

      <div className="mb-6 max-w-md relative">
        <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
        <Input
          placeholder="Buscar por solicitante..."
          className="pl-9"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
        />
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32 w-full rounded-xl" />
          ))}
        </div>
      ) : (
        <div className="space-y-4">
          {filteredRequests && filteredRequests.length > 0 ? (
            filteredRequests.map((req) => (
              <Card key={req.id} className="bg-card border-border border-l-4 border-l-amber-500">
                <CardContent className="p-4 sm:p-6 flex flex-col md:flex-row gap-6">
                  <div className="flex-1 space-y-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <div className="flex items-center gap-2 mb-1">
                          <Badge variant="outline" className="bg-amber-500/10 text-amber-500 border-amber-500/20">
                            <Clock className="w-3 h-3 mr-1" /> Pendente
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {req.createdAt ? format(new Date(req.createdAt), "dd/MM/yyyy HH:mm") : ""}
                          </span>
                        </div>
                        <h3 className="font-semibold text-lg">Apontamento #{req.confirmationId}</h3>
                      </div>
                    </div>
                    
                    <div className="bg-secondary/50 p-3 rounded-md">
                      <div className="text-xs font-semibold uppercase tracking-wider text-muted-foreground mb-1">Motivo da Solicitação</div>
                      <p className="text-sm">{req.reason}</p>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="w-6 h-6 rounded-full bg-primary/20 flex items-center justify-center text-primary text-xs font-bold">
                        {req.requestedByName?.charAt(0) || "U"}
                      </div>
                      <span className="text-sm font-medium">{req.requestedByName}</span>
                      <span className="text-xs text-muted-foreground">({req.requestedBy})</span>
                    </div>
                  </div>

                  <div className="flex flex-row md:flex-col justify-end gap-2 md:w-32 shrink-0 border-t md:border-t-0 md:border-l border-border pt-4 md:pt-0 md:pl-6">
                    <Button 
                      className="flex-1 md:flex-none w-full bg-green-600 hover:bg-green-700 text-white" 
                      onClick={() => handleAction(req.id, EditRequestUpdateStatus.approved)}
                      disabled={updateRequestMutation.isPending}
                    >
                      <CheckCircle className="w-4 h-4 mr-2" /> Aprovar
                    </Button>
                    <Button 
                      variant="outline" 
                      className="flex-1 md:flex-none w-full text-destructive hover:bg-destructive/10 hover:text-destructive"
                      onClick={() => handleAction(req.id, EditRequestUpdateStatus.rejected)}
                      disabled={updateRequestMutation.isPending}
                    >
                      <XCircle className="w-4 h-4 mr-2" /> Rejeitar
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="py-16 text-center border rounded-lg bg-card/50">
              <CheckCircle className="w-12 h-12 text-muted-foreground mx-auto mb-4 opacity-50" />
              <h3 className="text-lg font-medium">Nenhuma solicitação pendente</h3>
              <p className="text-muted-foreground mt-1">Todas as solicitações foram avaliadas.</p>
            </div>
          )}
        </div>
      )}
    </AdminLayout>
  );
}
