import { AdminLayout } from "@/components/layout/AdminLayout";
import {
  useGetServiceOrder,
  getGetServiceOrderQueryKey,
  useUpdateServiceOrder,
  useListUsers,
  getListUsersQueryKey,
  useGetServiceOrderSignatures,
  getGetServiceOrderSignaturesQueryKey,
  useSaveServiceOrderSignature,
  useDeleteServiceOrderSignature,
} from "@workspace/api-client-react";
import { useParams, Link } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import {
  ArrowLeft, Clock, AlertCircle, Wrench, Settings, UserCheck,
  Check, X, FileDown, PenLine, Trash2, CheckCircle2, ShieldCheck, Users,
  Timer, FileText, Camera, User,
} from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import SignatureModal from "@/components/SignatureModal";
import { exportOrderPdf } from "@/utils/exportOrderPdf";
import { useToast } from "@/hooks/use-toast";

const SIGNER_TYPES = [
  { key: "executor", label: "Executor", icon: PenLine, color: "text-blue-400", bg: "bg-blue-400/10 border-blue-400/30" },
  { key: "area_responsible", label: "Resp. Área / Solicitante", icon: ShieldCheck, color: "text-amber-400", bg: "bg-amber-400/10 border-amber-400/30" },
  { key: "immediate_supervisor", label: "Supervisão Imediata", icon: CheckCircle2, color: "text-green-400", bg: "bg-green-400/10 border-green-400/30" },
] as const;

export default function AdminOrderDetail() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [editingAssign, setEditingAssign] = useState(false);
  const [selectedMatricula, setSelectedMatricula] = useState<string>("");
  const [activeSignerModal, setActiveSignerModal] = useState<string | null>(null);

  const { data: order, isLoading } = useGetServiceOrder(id, {
    query: { queryKey: getGetServiceOrderQueryKey(id), enabled: !!id },
  });

  const { data: users } = useListUsers(
    { role: "user", active: true },
    { query: { queryKey: getListUsersQueryKey({ role: "user", active: true }) } }
  );

  const { data: signatures = [], isLoading: sigsLoading } = useGetServiceOrderSignatures(id, {
    query: { queryKey: getGetServiceOrderSignaturesQueryKey(id), enabled: !!id },
  });

  const { mutate: updateOrder, isPending: isSavingOrder } = useUpdateServiceOrder({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetServiceOrderQueryKey(id) });
        setEditingAssign(false);
        toast({ title: "Responsável atribuído com sucesso." });
      },
      onError: () => {
        toast({ title: "Erro ao salvar atribuição.", variant: "destructive" });
      },
    },
  });

  const { mutate: saveSig, isPending: isSavingSig } = useSaveServiceOrderSignature({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetServiceOrderSignaturesQueryKey(id) });
        setActiveSignerModal(null);
      },
    },
  });

  const { mutate: deleteSig } = useDeleteServiceOrderSignature({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetServiceOrderSignaturesQueryKey(id) });
      },
    },
  });

  const handleAssignStart = () => {
    setSelectedMatricula((order as any)?.assignedMatricula || "");
    setEditingAssign(true);
  };

  const handleAssignSave = () => {
    const user = users?.find((u) => u.matricula === selectedMatricula);
    updateOrder({
      id,
      data: {
        assignedMatricula: selectedMatricula === "none" ? null : selectedMatricula || null,
        assignedName: selectedMatricula === "none" ? null : (user?.name || null),
      },
    });
  };

  const handleSignatureSave = (data: { signerName: string; signerMatricula: string; signatureData: string }) => {
    if (!activeSignerModal) return;
    saveSig({
      id,
      data: {
        signerType: activeSignerModal as any,
        signerName: data.signerName,
        signerMatricula: data.signerMatricula || null,
        signatureData: data.signatureData,
      },
    });
  };

  const handleDeleteSig = (signerType: string) => {
    if (confirm("Remover esta assinatura?")) {
      deleteSig({ id, signerType });
    }
  };

  const handleExportPdf = () => {
    if (!order) return;
    exportOrderPdf(order as any, signatures as any);
  };

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="space-y-4">
          <Skeleton className="h-8 w-64 mb-6" />
          <Skeleton className="h-40 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </AdminLayout>
    );
  }

  if (!order)
    return (
      <AdminLayout>
        <div className="p-8 text-center text-muted-foreground">Ordem não encontrada.</div>
      </AdminLayout>
    );

  const sigsMap = Object.fromEntries((signatures as any[]).map((s: any) => [s.signerType, s]));
  const allSigned = SIGNER_TYPES.every((t) => sigsMap[t.key]);
  const assignedMatricula = (order as any).assignedMatricula;
  const assignedName = (order as any).assignedName;

  return (
    <AdminLayout>
      {activeSignerModal && (
        <SignatureModal
          title={`Assinatura: ${SIGNER_TYPES.find((t) => t.key === activeSignerModal)?.label}`}
          onSave={handleSignatureSave}
          onClose={() => setActiveSignerModal(null)}
          isSaving={isSavingSig}
        />
      )}

      <div className="mb-6">
        <Link href="/admin/ordens" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar para Ordens
        </Link>
        <div className="flex flex-col md:flex-row justify-between md:items-center gap-4">
          <div>
            <h1 className="text-2xl font-bold tracking-tight text-primary flex items-center gap-2">
              <Wrench className="w-6 h-6" /> OS {order.orderNumber}
            </h1>
            <p className="text-muted-foreground text-lg">{order.description}</p>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <Badge
              variant="outline"
              className={order.type === "preventive" ? "text-blue-400 border-blue-400/20" : "text-amber-500 border-amber-500/20"}
            >
              {order.type === "preventive" ? (
                <><Clock className="w-3 h-3 mr-1" /> Preventiva</>
              ) : (
                <><AlertCircle className="w-3 h-3 mr-1" /> Corretiva</>
              )}
            </Badge>
            <Badge variant={order.status === "in_progress" ? "default" : order.status === "completed" ? "secondary" : "outline"}>
              {order.status === "open" ? "Aberta" : order.status === "in_progress" ? "Em Andamento" : "Concluída"}
            </Badge>
            <Button variant="outline" size="sm" onClick={handleExportPdf}>
              <FileDown className="w-4 h-4 mr-2" />
              Exportar PDF
            </Button>
          </div>
        </div>
      </div>

      {/* Details + Responsável */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Detalhes Técnicos</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {[["Equipamento", order.equipment], ["Centro de Custo", order.costCenter], ["Local", order.location]].map(([l, v]) => (
              <div key={l} className="flex justify-between border-b border-border/50 pb-1">
                <span className="text-muted-foreground">{l}:</span>
                <span className="font-medium">{v || "-"}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Planejamento</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2 text-sm">
            {[["Data Abertura", order.openDate], ["Duração Esperada", order.expectedDuration ? `${order.expectedDuration}h` : null], ["Tipo de Atividade", order.activityType]].map(([l, v]) => (
              <div key={l} className="flex justify-between border-b border-border/50 pb-1">
                <span className="text-muted-foreground">{l}:</span>
                <span className="font-medium">{v || "-"}</span>
              </div>
            ))}
          </CardContent>
        </Card>

        {/* OS-level assignment card */}
        <Card className={`border ${assignedMatricula ? "border-primary/30 bg-primary/5" : "border-border bg-card"}`}>
          <CardHeader className="pb-2">
            <div className="flex items-center justify-between">
              <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1">
                <Users className="w-3.5 h-3.5" /> Responsável pela OS
              </CardTitle>
              {!editingAssign && (
                <Button variant="ghost" size="sm" className="h-7 text-xs" onClick={handleAssignStart}>
                  <UserCheck className="w-3 h-3 mr-1" /> {assignedMatricula ? "Alterar" : "Atribuir"}
                </Button>
              )}
            </div>
          </CardHeader>
          <CardContent>
            {editingAssign ? (
              <div className="space-y-3">
                <Select value={selectedMatricula} onValueChange={setSelectedMatricula}>
                  <SelectTrigger className="h-9 text-sm">
                    <SelectValue placeholder="Selecionar responsável..." />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="none">Sem responsável</SelectItem>
                    {users?.map((u) => (
                      <SelectItem key={u.matricula} value={u.matricula}>
                        {u.name} ({u.matricula})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <div className="flex gap-2">
                  <Button size="sm" className="flex-1 h-8" onClick={handleAssignSave} disabled={isSavingOrder}>
                    <Check className="w-3.5 h-3.5 mr-1" /> {isSavingOrder ? "Salvando..." : "Salvar"}
                  </Button>
                  <Button size="sm" variant="ghost" className="h-8" onClick={() => setEditingAssign(false)}>
                    <X className="w-3.5 h-3.5" />
                  </Button>
                </div>
              </div>
            ) : assignedMatricula ? (
              <div className="space-y-2">
                <div className="flex items-center gap-2">
                  <div className="w-9 h-9 rounded-full bg-primary/20 flex items-center justify-center text-sm font-bold text-primary">
                    {(assignedName || assignedMatricula).charAt(0)}
                  </div>
                  <div>
                    <p className="font-semibold text-sm">{assignedName || assignedMatricula}</p>
                    <p className="text-xs text-muted-foreground font-mono">{assignedMatricula}</p>
                  </div>
                </div>
                <Badge className="bg-primary/20 text-primary border-primary/30 text-xs w-fit">
                  <UserCheck className="w-3 h-3 mr-1" /> Atribuído
                </Badge>
              </div>
            ) : (
              <div className="py-2 text-sm text-muted-foreground italic">
                Nenhum responsável atribuído a esta OS.
              </div>
            )}

            {/* Signature counter at the bottom */}
            <div className="mt-3 pt-2 border-t border-border/40">
              {allSigned ? (
                <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                  <CheckCircle2 className="w-3 h-3 mr-1" /> Todas assinaturas coletadas
                </Badge>
              ) : (
                <span className="text-xs text-muted-foreground">{(signatures as any[]).length}/3 assinaturas</span>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Operations */}
      <div className="flex items-center justify-between mb-4">
        <h2 className="text-xl font-bold tracking-tight flex items-center gap-2">
          <Settings className="w-5 h-5" /> Linhas de Operação
        </h2>
        <span className="text-xs text-muted-foreground">{(order.lines as any)?.length || 0} operação(ões)</span>
      </div>

      <div className="space-y-4 mb-8">
        {(order.lines as any) && (order.lines as any).length > 0 ? (
          (order.lines as any[]).map((line: any) => {
            const confs: any[] = line.confirmations || [];
            const isActive = confs.some((c: any) => c.status === "started" || c.status === "paused");
            const isDone = !isActive && confs.some((c: any) => c.status === "finished" || c.status === "edited");
            const doneConfs = confs.filter((c: any) => c.status === "finished" || c.status === "edited");
            return (
              <div key={line.id} className={`rounded-xl border p-4 ${isDone ? "border-green-500/30 bg-green-500/5" : isActive ? "border-amber-400/30 bg-amber-400/5" : "border-border bg-card"}`}>
                {/* Line header */}
                <div className="flex items-center gap-3 flex-wrap mb-2">
                  <span className="font-mono font-bold text-primary">{line.opNumber}{line.subOp ? `.${line.subOp}` : ""}</span>
                  {line.centTrab && <Badge variant="outline" className="text-xs">{line.centTrab}</Badge>}
                  {line.expectedTime && (
                    <span className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="w-3 h-3" /> {line.expectedTime}h prev.
                    </span>
                  )}
                  <div className="ml-auto">
                    {isDone ? (
                      <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                        <CheckCircle2 className="w-3 h-3 mr-1" /> Finalizado
                      </Badge>
                    ) : isActive ? (
                      <Badge className="bg-amber-400/20 text-amber-400 border-amber-400/30 text-xs">Em Andamento</Badge>
                    ) : (
                      <Badge variant="outline" className="text-xs text-muted-foreground">Pendente</Badge>
                    )}
                  </div>
                </div>
                <p className="text-sm text-foreground mb-3">{line.description}</p>

                {/* Confirmation history */}
                {doneConfs.length > 0 && (
                  <div className="space-y-3 mt-2 pl-2 border-l-2 border-primary/20">
                    <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1">
                      <FileText className="w-3 h-3" /> Histórico de Apontamentos ({doneConfs.length})
                    </p>
                    {doneConfs.map((c: any) => {
                      let parsedPhotos: any[] = [];
                      try { parsedPhotos = c.photos ? JSON.parse(c.photos) : []; } catch {}
                      const beforePhoto = parsedPhotos.find((p: any) => p.type === "before");
                      const afterPhoto = parsedPhotos.find((p: any) => p.type === "after");
                      const machinePhoto = parsedPhotos.find((p: any) => p.type === "machine_code");
                      return (
                        <div key={c.id} className="bg-background/60 rounded-lg p-3 space-y-2 border border-border/40">
                          {/* Header row */}
                          <div className="flex items-center justify-between flex-wrap gap-2">
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              <Timer className="w-3 h-3" />
                              <span>{c.startDate} {c.startTime?.slice(0, 5)} → {c.endDate} {c.endTime?.slice(0, 5)}</span>
                              {c.realWork !== null && c.realWork !== undefined && (
                                <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">
                                  {c.realWork}h trabalhadas
                                </Badge>
                              )}
                            </div>
                            <div className="flex items-center gap-1 text-xs text-muted-foreground">
                              <User className="w-3 h-3" />
                              <span>{c.employeeMatricula}</span>
                              {c.coWorkerMatricula && <span className="ml-1">+ ajudante: {c.coWorkerMatricula}</span>}
                            </div>
                          </div>

                          {/* Observation */}
                          {c.observation && (
                            <div className="flex items-start gap-2 text-sm">
                              <FileText className="w-3 h-3 mt-0.5 text-muted-foreground shrink-0" />
                              <p className="text-foreground">{c.observation}</p>
                            </div>
                          )}

                          {/* Root cause */}
                          {c.rootCauseId && (
                            <div className="text-xs text-amber-400 flex items-center gap-1">
                              <AlertCircle className="w-3 h-3" />
                              Causa Raiz registrada (ID: {c.rootCauseId})
                            </div>
                          )}

                          {/* Justification */}
                          {c.justification && (
                            <div className="text-xs text-orange-400 flex items-center gap-1 bg-orange-400/10 px-2 py-1 rounded">
                              <AlertCircle className="w-3 h-3" /> Justificativa: {c.justification}
                            </div>
                          )}

                          {/* Photos */}
                          {(machinePhoto || beforePhoto || afterPhoto) && (
                            <div className="flex items-center gap-2 flex-wrap">
                              <Camera className="w-3 h-3 text-muted-foreground" />
                              {[
                                { photo: machinePhoto, label: "Código/Tag" },
                                { photo: beforePhoto, label: "Antes" },
                                { photo: afterPhoto, label: "Depois" },
                              ].filter((e) => e.photo).map(({ photo, label }) => (
                                <div key={label} className="relative">
                                  <img src={photo.data} alt={label} className="h-16 w-16 rounded object-cover border border-border" />
                                  <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-[10px] text-center rounded-b py-0.5">{label}</div>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                )}

                {/* Active confirmations info */}
                {isActive && confs.filter((c: any) => c.status === "started" || c.status === "paused").map((c: any) => (
                  <div key={c.id} className="mt-2 text-xs text-amber-400 flex items-center gap-2 bg-amber-400/10 px-3 py-2 rounded-lg border border-amber-400/20">
                    <Timer className="w-3 h-3" />
                    <span>
                      Apontamento {c.status === "paused" ? "pausado" : "em andamento"} por {c.employeeMatricula}
                      {c.startDate && ` — iniciado em ${c.startDate} ${c.startTime?.slice(0, 5)}`}
                    </span>
                  </div>
                ))}
              </div>
            );
          })
        ) : (
          <div className="p-8 text-center border rounded-lg bg-card text-muted-foreground">Nenhuma operação cadastrada para esta ordem.</div>
        )}
      </div>

      {/* Signatures */}
      <div className="mb-4">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-xl font-bold tracking-tight flex items-center gap-2">
            <PenLine className="w-5 h-5" /> Assinaturas de Aprovação
          </h2>
          {allSigned && (
            <Button variant="outline" size="sm" onClick={handleExportPdf}>
              <FileDown className="w-4 h-4 mr-2" />
              Exportar OS com Assinaturas (PDF)
            </Button>
          )}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {SIGNER_TYPES.map(({ key, label, icon: Icon, color, bg }) => {
            const sig = sigsMap[key];
            return (
              <div key={key} className={`rounded-xl border p-5 flex flex-col gap-3 ${bg}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Icon className={`w-4 h-4 ${color}`} />
                    <span className={`text-sm font-semibold ${color}`}>{label}</span>
                  </div>
                  {sig && (
                    <button onClick={() => handleDeleteSig(key)} title="Remover assinatura" className="text-muted-foreground hover:text-red-400">
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  )}
                </div>

                {sigsLoading ? (
                  <Skeleton className="h-24 w-full" />
                ) : sig ? (
                  <>
                    <div className="bg-white rounded-lg overflow-hidden border border-border/30">
                      <img src={sig.signatureData} alt="assinatura" className="w-full h-24 object-contain" />
                    </div>
                    <div>
                      <p className="font-semibold text-sm">{sig.signerName}</p>
                      {sig.signerMatricula && (
                        <p className="text-xs text-muted-foreground">Matrícula: {sig.signerMatricula}</p>
                      )}
                      <p className="text-xs text-muted-foreground">
                        {sig.signedAt ? new Date(sig.signedAt).toLocaleString("pt-BR") : ""}
                      </p>
                    </div>
                    <Badge className="bg-green-500/20 text-green-400 border-green-500/30 w-fit">
                      <Check className="w-3 h-3 mr-1" /> Assinado
                    </Badge>
                  </>
                ) : (
                  <>
                    <div className="flex-1 border-2 border-dashed border-border/40 rounded-lg flex items-center justify-center h-24 text-xs text-muted-foreground italic">
                      Aguardando assinatura
                    </div>
                    <Button variant="outline" size="sm" className="w-full" onClick={() => setActiveSignerModal(key)}>
                      <PenLine className="w-3.5 h-3.5 mr-2" />
                      Assinar
                    </Button>
                  </>
                )}
              </div>
            );
          })}
        </div>

        {!allSigned && (
          <p className="text-xs text-muted-foreground mt-3">
            O PDF com todas as assinaturas ficará disponível após os 3 campos serem assinados. Você também pode exportar a qualquer momento pelo botão acima.
          </p>
        )}
      </div>
    </AdminLayout>
  );
}
