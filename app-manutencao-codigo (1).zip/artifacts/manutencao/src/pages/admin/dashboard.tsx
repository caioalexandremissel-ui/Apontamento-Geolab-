import { AdminLayout } from "@/components/layout/AdminLayout";
import {
  useGetDashboardSummary,
  useListConfirmations,
  getListConfirmationsQueryKey,
} from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Activity, CheckCircle, Clock, FileText, AlertTriangle, Users, Radio, Wrench } from "lucide-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { Badge } from "@/components/ui/badge";
import { useEffect, useState } from "react";

function LiveDot() {
  const [on, setOn] = useState(true);
  useEffect(() => {
    const t = setInterval(() => setOn((v) => !v), 800);
    return () => clearInterval(t);
  }, []);
  return <span className={`inline-block w-2 h-2 rounded-full bg-green-400 transition-opacity ${on ? "opacity-100" : "opacity-30"}`} />;
}

export default function AdminDashboard() {
  const { data: summary, isLoading } = useGetDashboardSummary();

  const { data: activeConfs = [], isLoading: activeLoading } = useListConfirmations(
    { status: "started" },
    { query: { queryKey: getListConfirmationsQueryKey({ status: "started" }), refetchInterval: 15000 } }
  );

  if (isLoading) {
    return (
      <AdminLayout>
        <div className="space-y-6">
          <div>
            <Skeleton className="h-10 w-64 mb-2" />
            <Skeleton className="h-5 w-96" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {[...Array(5)].map((_, i) => (
              <Skeleton key={i} className="h-32 w-full rounded-xl" />
            ))}
          </div>
        </div>
      </AdminLayout>
    );
  }

  return (
    <AdminLayout>
      <div className="mb-6">
        <h1 className="text-3xl font-bold tracking-tight mb-2">Painel de Controle</h1>
        <p className="text-muted-foreground">Visão geral das operações de manutenção.</p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 mb-8">
        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total de OS</CardTitle>
            <FileText className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{(summary as any)?.total || (summary as any)?.totalOrders || 0}</div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">OS Abertas</CardTitle>
            <Clock className="w-4 h-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{(summary as any)?.open || (summary as any)?.openOrders || 0}</div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Concluídas</CardTitle>
            <CheckCircle className="w-4 h-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-500">{(summary as any)?.completed || (summary as any)?.completedToday || 0}</div>
          </CardContent>
        </Card>

        <Card className="bg-card border-border relative overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Solicitações</CardTitle>
            <AlertTriangle className={`w-4 h-4 ${((summary as any)?.pendingEditRequests || 0) > 0 ? "text-destructive" : "text-muted-foreground"}`} />
          </CardHeader>
          <CardContent>
            <div className={`text-2xl font-bold ${((summary as any)?.pendingEditRequests || 0) > 0 ? "text-destructive" : ""}`}>
              {(summary as any)?.pendingEditRequests || 0}
            </div>
            {((summary as any)?.pendingEditRequests || 0) > 0 && (
              <Link href="/admin/solicitacoes" className="absolute inset-0 z-10" aria-label="Ver solicitações" />
            )}
          </CardContent>
        </Card>

        <Card className="bg-card border-border">
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Colaboradores</CardTitle>
            <Users className="w-4 h-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{(summary as any)?.totalEmployees || 0}</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Real-time active services */}
        <Card className="bg-card border-border">
          <CardHeader className="border-b border-border pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="flex items-center gap-2">
                <Radio className="w-4 h-4 text-primary" />
                Em Serviço Agora
              </CardTitle>
              <div className="flex items-center gap-1.5 text-xs text-green-400">
                <LiveDot />
                Atualizado a cada 15s
              </div>
            </div>
          </CardHeader>
          <CardContent className="pt-4">
            {activeLoading ? (
              <div className="space-y-3">
                {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-14 w-full" />)}
              </div>
            ) : (activeConfs as any[]).length > 0 ? (
              <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
                {(activeConfs as any[]).map((c: any) => (
                  <div key={c.id} className="flex items-start gap-3 p-3 rounded-lg border border-amber-400/20 bg-amber-400/5">
                    <div className="w-8 h-8 rounded-full bg-amber-400/20 flex items-center justify-center text-xs font-bold text-amber-400 shrink-0">
                      {(c.employeeName || c.employeeMatricula).charAt(0)}
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-sm truncate">{c.employeeName || c.employeeMatricula}</div>
                      <div className="text-xs text-muted-foreground flex items-center gap-1">
                        <Wrench className="w-3 h-3" />
                        <span className="truncate">{c.lineDescription || "—"}</span>
                      </div>
                      {c.serviceOrderNumber && (
                        <Link href={`/admin/ordens/${c.serviceOrderId}`}>
                          <span className="text-xs text-primary font-mono hover:underline">OS {c.serviceOrderNumber}</span>
                        </Link>
                      )}
                    </div>
                    <div className="text-right shrink-0">
                      <Badge className="bg-amber-400/20 text-amber-400 border-amber-400/30 text-xs">Em serviço</Badge>
                      <div className="text-xs text-muted-foreground mt-1">{c.startTime}</div>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-muted-foreground text-sm">
                <Activity className="w-8 h-8 mx-auto mb-2 opacity-30" />
                Nenhum colaborador em serviço no momento.
              </div>
            )}
          </CardContent>
        </Card>

        {/* Recent orders */}
        <Card className="bg-card border-border">
          <CardHeader className="border-b border-border pb-3">
            <CardTitle>Últimas Ordens de Serviço</CardTitle>
          </CardHeader>
          <CardContent className="pt-4">
            <div className="space-y-3 max-h-72 overflow-y-auto pr-1">
              {(summary as any)?.recentOrders && (summary as any).recentOrders.length > 0 ? (
                (summary as any).recentOrders.map((os: any) => (
                  <div key={os.id} className="flex items-center justify-between p-3 rounded-lg bg-secondary/50 border border-border">
                    <div className="min-w-0 flex-1">
                      <div className="font-mono text-sm font-bold text-primary">{os.orderNumber}</div>
                      <div className="text-sm text-foreground truncate max-w-[200px]">{os.description}</div>
                    </div>
                    <div className="text-right shrink-0 ml-3">
                      <div className="text-xs uppercase tracking-wider font-semibold text-muted-foreground">
                        {os.type === "preventive" ? "Preventiva" : "Corretiva"}
                      </div>
                      <Link href={`/admin/ordens/${os.id}`} className="text-xs text-primary hover:underline">
                        Ver detalhes
                      </Link>
                    </div>
                  </div>
                ))
              ) : (
                <div className="text-center py-8 text-muted-foreground text-sm">Nenhuma ordem de serviço recente.</div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </AdminLayout>
  );
}
