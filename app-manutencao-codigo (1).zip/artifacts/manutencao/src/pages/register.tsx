import { useLocation, Link } from "wouter";
import { useCreateUser, UserInputRole } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Activity, ArrowLeft } from "lucide-react";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

const registerSchema = z.object({
  name: z.string().min(3, "Nome completo é obrigatório"),
  matricula: z.string().min(1, "Matrícula é obrigatória"),
  centTrab: z.string().optional(),
});

export default function Register() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const createUserMutation = useCreateUser();

  const form = useForm<z.infer<typeof registerSchema>>({
    resolver: zodResolver(registerSchema),
    defaultValues: { name: "", matricula: "", centTrab: "" },
  });

  const onSubmit = (data: z.infer<typeof registerSchema>) => {
    createUserMutation.mutate(
      { 
        data: {
          ...data,
          role: UserInputRole.user,
          active: true,
        }
      },
      {
        onSuccess: () => {
          toast({
            title: "Cadastro realizado com sucesso!",
            description: "Você já pode acessar o sistema.",
          });
          setLocation("/");
        },
        onError: () => {
          toast({
            title: "Erro no cadastro",
            description: "Verifique os dados ou se a matrícula já existe.",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="min-h-screen bg-background flex flex-col justify-center py-12 sm:px-6 lg:px-8">
      <div className="absolute top-8 left-8 flex items-center gap-2 text-primary font-bold text-xl">
        <Activity className="w-6 h-6" />
        <span>GeoLab Manutenção</span>
      </div>

      <div className="sm:mx-auto sm:w-full sm:max-w-md">
        <h2 className="mt-6 text-center text-3xl font-extrabold text-foreground">
          Registro de Operador
        </h2>
        <p className="mt-2 text-center text-sm text-muted-foreground">
          Acesso exclusivo para apontamento em campo
        </p>
      </div>

      <div className="mt-8 sm:mx-auto sm:w-full sm:max-w-md">
        <div className="bg-card py-8 px-4 shadow-xl sm:rounded-lg sm:px-10 border border-border">
          
          <Alert className="mb-6 bg-secondary border-primary/20 text-foreground">
            <AlertTitle className="text-primary font-medium">Atenção</AlertTitle>
            <AlertDescription className="text-muted-foreground text-xs mt-1">
              Sua <strong>matrícula</strong> será utilizada como sua senha de acesso inicial. Você poderá alterá-la posteriormente.
            </AlertDescription>
          </Alert>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-5">
              <FormField
                control={form.control}
                name="name"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Nome Completo</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: João da Silva" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="matricula"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Matrícula SAP</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: 123456" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <FormField
                control={form.control}
                name="centTrab"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Centro de Trabalho (Opcional)</FormLabel>
                    <FormControl>
                      <Input placeholder="Ex: MEC01" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />

              <div className="pt-2">
                <Button type="submit" className="w-full" disabled={createUserMutation.isPending}>
                  {createUserMutation.isPending ? "Registrando..." : "Confirmar Registro"}
                </Button>
              </div>
            </form>
          </Form>

          <div className="mt-6 text-center">
            <Link href="/" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Voltar para o login
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
}
