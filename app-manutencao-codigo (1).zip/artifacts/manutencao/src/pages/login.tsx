import { useState } from "react";
import { useLocation, Link } from "wouter";
import { useAuth } from "@/contexts/AuthContext";
import { useLogin, LoginInput } from "@workspace/api-client-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Activity, ShieldAlert, User, ChevronRight } from "lucide-react";

const loginSchema = z.object({
  matricula: z.string().min(1, "Matrícula é obrigatória"),
  password: z.string().min(1, "Senha é obrigatória"),
});

export default function Login() {
  const [, setLocation] = useLocation();
  const { login } = useAuth();
  const { toast } = useToast();
  const loginMutation = useLogin();

  const [activeSide, setActiveSide] = useState<"admin" | "user" | null>(null);

  const adminForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { matricula: "", password: "" },
  });

  const userForm = useForm<z.infer<typeof loginSchema>>({
    resolver: zodResolver(loginSchema),
    defaultValues: { matricula: "", password: "" },
  });

  const onSubmit = (data: z.infer<typeof loginSchema>, role: "admin" | "user") => {
    loginMutation.mutate(
      { data },
      {
        onSuccess: (res) => {
          if (res.user.role !== role) {
            toast({
              title: "Acesso Negado",
              description: `Este usuário não tem permissão de ${role === "admin" ? "Administrador" : "Usuário"}.`,
              variant: "destructive",
            });
            return;
          }
          login(res);
          setLocation(role === "admin" ? "/admin" : "/user");
        },
        onError: () => {
          toast({
            title: "Erro no Login",
            description: "Matrícula ou senha incorretos.",
            variant: "destructive",
          });
        },
      }
    );
  };

  return (
    <div className="min-h-screen w-full flex flex-col md:flex-row bg-background overflow-hidden">
      {/* Admin Side */}
      <div 
        className={`flex-1 transition-all duration-500 flex flex-col justify-center relative ${
          activeSide === "user" ? "opacity-30 blur-sm scale-95 pointer-events-none hidden md:flex" : "opacity-100 z-10"
        } ${activeSide === "admin" ? "bg-secondary" : "bg-card"}`}
        onMouseEnter={() => !activeSide && setActiveSide("admin")}
        onMouseLeave={() => !activeSide && setActiveSide(null)}
      >
        <div className="absolute top-8 left-8 flex items-center gap-2 text-primary font-bold text-xl">
          <Activity className="w-6 h-6" />
          <span>GeoLab</span>
        </div>

        <div className="max-w-md w-full mx-auto p-8 relative z-20">
          <div className="mb-8 text-center md:text-left">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 mx-auto md:mx-0">
              <ShieldAlert className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Administração</h1>
            <p className="text-muted-foreground mt-2">Gestão de apontamentos e controle de operações.</p>
          </div>

          <Form {...adminForm}>
            <form onSubmit={adminForm.handleSubmit((d) => onSubmit(d, "admin"))} className="space-y-4">
              <FormField
                control={adminForm.control}
                name="matricula"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Matrícula Admin</FormLabel>
                    <FormControl>
                      <Input placeholder="Digite sua matrícula" {...field} className="bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={adminForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Senha</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} className="bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full mt-4" disabled={loginMutation.isPending && activeSide === "admin"}>
                Entrar no Painel <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </form>
          </Form>
        </div>
      </div>

      {/* Divider */}
      <div className="hidden md:flex w-px bg-border z-20" />

      {/* User Side */}
      <div 
        className={`flex-1 transition-all duration-500 flex flex-col justify-center relative ${
          activeSide === "admin" ? "opacity-30 blur-sm scale-95 pointer-events-none hidden md:flex" : "opacity-100 z-10"
        } ${activeSide === "user" ? "bg-secondary" : "bg-card"}`}
        onMouseEnter={() => !activeSide && setActiveSide("user")}
        onMouseLeave={() => !activeSide && setActiveSide(null)}
      >
        <div className="max-w-md w-full mx-auto p-8 relative z-20">
          <div className="mb-8 text-center md:text-left">
            <div className="w-16 h-16 bg-primary/10 rounded-2xl flex items-center justify-center mb-6 mx-auto md:mx-0">
              <User className="w-8 h-8 text-primary" />
            </div>
            <h1 className="text-3xl font-bold tracking-tight text-foreground">Operação</h1>
            <p className="text-muted-foreground mt-2">Apontamento de ordens de serviço em campo.</p>
          </div>

          <Form {...userForm}>
            <form onSubmit={userForm.handleSubmit((d) => onSubmit(d, "user"))} className="space-y-4">
              <FormField
                control={userForm.control}
                name="matricula"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Matrícula</FormLabel>
                    <FormControl>
                      <Input placeholder="Digite sua matrícula" {...field} className="bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={userForm.control}
                name="password"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Senha</FormLabel>
                    <FormControl>
                      <Input type="password" placeholder="••••••••" {...field} className="bg-background" />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <Button type="submit" className="w-full mt-4" disabled={loginMutation.isPending && activeSide === "user"}>
                Acessar Terminal <ChevronRight className="w-4 h-4 ml-2" />
              </Button>
            </form>
          </Form>

          <div className="mt-8 text-center">
            <p className="text-sm text-muted-foreground">
              Primeiro acesso? <Link href="/cadastro" className="text-primary hover:underline font-medium">Cadastre-se aqui</Link>
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
