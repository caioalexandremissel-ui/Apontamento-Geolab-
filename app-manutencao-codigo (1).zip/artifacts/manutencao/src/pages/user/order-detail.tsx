import { UserLayout } from "@/components/layout/UserLayout";
import {
  useGetServiceOrder,
  getGetServiceOrderQueryKey,
  useUpdateServiceOrder,
} from "@workspace/api-client-react";
import { useParams, Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  ArrowLeft, Clock, AlertCircle, Wrench, CheckCircle2,
  ChevronRight, Play, AlertTriangle, Loader2, XCircle,
  FileText, User, Timer, Camera,
} from "lucide-react";
import { useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

function getLineStatus(line: any) {
  const confs = line.confirmations || [];
  if (confs.some((c: any) => c.status === "started" || c.status === "paused")) return "active";
  if (confs.some((c: any) => c.status === "finished" || c.status === "edited")) return "done";
  return "pending";
}

function ConfirmationHistory({ confirmations }: { confirmations: any[] }) {
  const done = confirmations.filter((c: any) => c.status === "finished" || c.status === "edited");
  if (done.length === 0) return null;

  return (
    <div className="mt-3 space-y-3">
      {done.map((c: any) => {
        let parsedPhotos: any[] = [];
        try { parsedPhotos = c.photos ? JSON.parse(c.photos) : []; } catch {}
        const beforePhoto = parsedPhotos.find((p: any) => p.type === "before");
        const afterPhoto = parsedPhotos.find((p: any) => p.type === "after");

        return (
          <div key={c.id} className="rounded-lg bg-green-500/5 border border-green-500/20 p-3 space-y-2">
            <div className="flex items-center justify-between flex-wrap gap-2">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <Timer className="w-3 h-3" />
                <span>
                  {c.startDate} {c.startTime?.slice(0, 5)} → {c.endDate} {c.endTime?.slice(0, 5)}
                </span>
                {c.realWork !== null && c.realWork !== undefined && (
                  <Badge className="bg-primary/20 text-primary border-primary/30 text-xs">
                    {c.realWork}h trabalhadas
                  </Badge>
                )}
              </div>
              <div className="flex items-center gap-1 text-xs text-muted-foreground">
                <User className="w-3 h-3" />
                <span>{c.employeeMatricula}</span>
                {c.coWorkerMatricula && <span>+ {c.coWorkerMatricula}</span>}
              </div>
            </div>

            {c.observation && (
              <div className="flex items-start gap-2 text-sm">
                <FileText className="w-3 h-3 mt-0.5 text-muted-foreground shrink-0" />
                <p className="text-foreground">{c.observation}</p>
              </div>
            )}

            {c.rootCauseId && (
              <div className="text-xs text-amber-400 flex items-center gap-1">
                <AlertCircle className="w-3 h-3" /> Causa raiz registrada (ID: {c.rootCauseId})
              </div>
            )}

            {c.justification && (
              <div className="text-xs text-orange-400 flex items-center gap-1 bg-orange-400/10 p-1.5 rounded">
                <AlertTriangle className="w-3 h-3" /> Justificativa: {c.justification}
              </div>
            )}

            {(beforePhoto || afterPhoto) && (
              <div className="flex gap-2 mt-1">
                <Camera className="w-3 h-3 text-muted-foreground mt-1" />
                {beforePhoto && (
                  <div className="relative">
                    <img src={beforePhoto.data} alt="Antes" className="h-16 w-16 rounded object-cover border border-border" />
                    <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-[10px] text-center rounded-b py-0.5">Antes</div>
                  </div>
                )}
                {afterPhoto && (
                  <div className="relative">
                    <img src={afterPhoto.data} alt="Depois" className="h-16 w-16 rounded object-cover border border-border" />
                    <div className="absolute bottom-0 left-0 right-0 bg-black/60 text-white text-[10px] text-center rounded-b py-0.5">Depois</div>
                  </div>
                )}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}

export default function UserOrderDetail() {
  const params = useParams();
  const id = parseInt(params.id || "0", 10);
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { toast } = useToast();

  const [showErrorForm, setShowErrorForm] = useState(false);
  const [errorObs, setErrorObs] = useState("");
  const [isFinishing, setIsFinishing] = useState(false);

  const { data: order, isLoading } = useGetServiceOrder(id, {
    query: { queryKey: getGetServiceOrderQueryKey(id), enabled: !!id },
  });

  const { mutate: updateOrder } = useUpdateServiceOrder({
    mutation: {
      onSuccess: () => {
        queryClient.invalidateQueries({ queryKey: getGetServiceOrderQueryKey(id) });
        toast({ title: "Ordem finalizada!", description: "A OS foi marcada como concluída com sucesso." });
        setLocation("/user");
      },
      onError: () => {
        toast({ title: "Erro ao finalizar", description: "Não foi possível finalizar a OS.", variant: "destructive" });
        setIsFinishing(false);
      },
    },
  });

  if (isLoading) {
    return (
      <UserLayout>
        <div className="space-y-4">
          <Skeleton className="h-8 w-64 mb-6" />
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      </UserLayout>
    );
  }

  if (!order)
    return (
      <UserLayout>
        <div className="p-8 text-center text-muted-foreground">Ordem não encontrada.</div>
      </UserLayout>
    );

  const lines: any[] = (order.lines as any) || [];
  const lineStatuses = lines.map((l) => getLineStatus(l));
  const doneCount = lineStatuses.filter((s) => s === "done").length;
  const activeCount = lineStatuses.filter((s) => s === "active").length;
  const allDone = lines.length > 0 && lineStatuses.every((s) => s === "done");

  const handleFinalize = () => {
    setIsFinishing(true);
    updateOrder({ id, data: { status: "completed" } });
  };

  const handleReportError = () => {
    if (!errorObs.trim()) {
      toast({ title: "Observação necessária", description: "Descreva o problema encontrado.", variant: "destructive" });
      return;
    }
    updateOrder({ id, data: { status: "completed" } });
    toast({ title: "Erro reportado", description: "A observação foi registrada." });
  };

  return (
    <UserLayout>
      <div className="mb-6">
        <Link href="/user" className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar para Ordens
        </Link>
        <div className="flex flex-col gap-2">
          <div className="flex items-center gap-2 flex-wrap">
            <Badge
              variant="outline"
              className={order.type === "preventive" ? "text-blue-400 border-blue-400/20" : "text-amber-500 border-amber-500/20"}
            >
              {order.type === "preventive" ? "Preventiva" : "Corretiva"}
            </Badge>
            <Badge variant={order.status === "completed" ? "secondary" : order.status === "in_progress" ? "default" : "outline"}>
              {order.status === "open" ? "Aberta" : order.status === "in_progress" ? "Em Andamento" : "Concluída"}
            </Badge>
          </div>
          <h1 className="text-3xl font-bold tracking-tight text-primary font-mono">{order.orderNumber}</h1>
          <p className="text-foreground text-lg">{order.description}</p>
        </div>
      </div>

      {/* Info strip */}
      <Card className="bg-card border-border mb-6">
        <CardContent className="p-4 grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
          <div>
            <div className="text-muted-foreground text-xs uppercase tracking-wider mb-1">Equipamento</div>
            <div className="font-medium flex items-center gap-1">
              <Wrench className="w-3 h-3 text-primary" /> {order.equipment || "-"}
            </div>
          </div>
          <div>
            <div className="text-muted-foreground text-xs uppercase tracking-wider mb-1">Local</div>
            <div className="font-medium">{order.location || "-"}</div>
          </div>
          <div>
            <div className="text-muted-foreground text-xs uppercase tracking-wider mb-1">Duração Est.</div>
            <div className="font-medium flex items-center gap-1">
              <Clock className="w-3 h-3 text-primary" /> {order.expectedDuration ? `${order.expectedDuration}h` : "-"}
            </div>
          </div>
          <div>
            <div className="text-muted-foreground text-xs uppercase tracking-wider mb-1">Abertura</div>
            <div className="font-medium">{order.openDate || "-"}</div>
          </div>
        </CardContent>
      </Card>

      {/* Progress bar */}
      <div className="mb-6">
        <div className="flex items-center justify-between mb-2">
          <span className="text-sm font-semibold">Progresso das Operações</span>
          <span className="text-sm text-muted-foreground">
            {doneCount}/{lines.length} finalizadas
            {activeCount > 0 && <span className="text-amber-400 ml-2">• {activeCount} em andamento</span>}
          </span>
        </div>
        <div className="h-2 bg-secondary rounded-full overflow-hidden">
          <div
            className="h-full bg-primary rounded-full transition-all"
            style={{ width: lines.length > 0 ? `${(doneCount / lines.length) * 100}%` : "0%" }}
          />
        </div>
      </div>

      {/* Lines */}
      <h2 className="text-xl font-bold tracking-tight mb-4 flex items-center gap-2">
        Operações ({lines.length})
      </h2>

      <div className="space-y-3 mb-8">
        {lines.length > 0 ? (
          lines.map((line, i) => {
            const status = lineStatuses[i];
            const confs: any[] = line.confirmations || [];
            return (
              <Card
                key={line.id}
                className={`border overflow-hidden ${
                  status === "done"
                    ? "border-green-500/30 bg-green-500/5"
                    : status === "active"
                    ? "border-amber-400/40 bg-amber-400/5"
                    : "border-border bg-card"
                }`}
              >
                <CardContent className="p-0">
                  <div className="flex flex-col md:flex-row">
                    <div className="p-4 flex-1">
                      <div className="flex items-center gap-2 mb-1 flex-wrap">
                        <span className="font-mono font-bold text-primary">OP {line.opNumber}</span>
                        {line.centTrab && <Badge variant="outline" className="text-xs">{line.centTrab}</Badge>}
                        {status === "done" && (
                          <Badge className="bg-green-500/20 text-green-400 border-green-500/30 text-xs">
                            <CheckCircle2 className="w-3 h-3 mr-1" /> Finalizado
                          </Badge>
                        )}
                        {status === "active" && (
                          <Badge className="bg-amber-400/20 text-amber-400 border-amber-400/30 text-xs">
                            <Loader2 className="w-3 h-3 mr-1 animate-spin" /> Em Andamento
                          </Badge>
                        )}
                        {status === "pending" && (
                          <Badge variant="outline" className="text-xs text-muted-foreground">
                            Pendente
                          </Badge>
                        )}
                      </div>
                      <p className="text-foreground">{line.description}</p>
                      {line.expectedTime && (
                        <p className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> Tempo previsto: {line.expectedTime}h
                        </p>
                      )}

                      {/* Confirmation history */}
                      <ConfirmationHistory confirmations={confs} />
                    </div>
                    <div
                      className={`p-4 md:w-44 flex items-center justify-center border-t md:border-t-0 md:border-l border-border/50 ${
                        status === "done" ? "bg-green-500/5" : "bg-secondary/20"
                      }`}
                    >
                      {status === "done" ? (
                        <Link href={`/user/ordens/${order.id}/linhas/${line.id}`} className="w-full">
                          <Button variant="ghost" className="w-full text-green-400 hover:text-green-300 text-sm">
                            <CheckCircle2 className="w-4 h-4 mr-1" /> Ver / Novo
                          </Button>
                        </Link>
                      ) : (
                        <Link href={`/user/ordens/${order.id}/linhas/${line.id}`} className="w-full">
                          <Button
                            className="w-full font-bold"
                            variant={status === "active" ? "default" : "secondary"}
                          >
                            {status === "active" ? (
                              <><Loader2 className="w-4 h-4 mr-1 animate-spin" /> Continuar</>
                            ) : (
                              <><Play className="w-4 h-4 mr-1" /> Iniciar</>
                            )}
                            <ChevronRight className="w-4 h-4 ml-1" />
                          </Button>
                        </Link>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })
        ) : (
          <div className="p-8 text-center border rounded-lg bg-card/50 text-muted-foreground">
            Nenhuma operação disponível.
          </div>
        )}
      </div>

      {/* Finalization area */}
      {allDone && order.status !== "completed" && !showErrorForm && (
        <div className="rounded-xl border border-green-500/40 bg-green-500/10 p-6 space-y-4">
          <div className="flex items-center gap-3">
            <CheckCircle2 className="w-8 h-8 text-green-400" />
            <div>
              <h3 className="text-lg font-bold text-green-400">Todas as operações concluídas!</h3>
              <p className="text-sm text-muted-foreground">
                Confirme para encerrar esta ordem de serviço ou reporte um problema.
              </p>
            </div>
          </div>
          <div className="flex gap-3 flex-wrap">
            <Button
              className="flex-1 min-w-[140px] bg-green-600 hover:bg-green-700 text-white font-bold h-12"
              onClick={handleFinalize}
              disabled={isFinishing}
            >
              {isFinishing ? (
                <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Finalizando...</>
              ) : (
                <><CheckCircle2 className="w-4 h-4 mr-2" /> Finalizar OS</>
              )}
            </Button>
            <Button
              className="flex-1 min-w-[140px] bg-red-600/80 hover:bg-red-600 text-white font-bold h-12"
              onClick={() => setShowErrorForm(true)}
            >
              <XCircle className="w-4 h-4 mr-2" /> Reportar Erro
            </Button>
          </div>
        </div>
      )}

      {/* Error report form */}
      {showErrorForm && (
        <div className="rounded-xl border border-red-500/40 bg-red-500/10 p-6 space-y-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-6 h-6 text-red-400" />
            <div>
              <h3 className="text-lg font-bold text-red-400">Reportar Problema</h3>
              <p className="text-xs text-muted-foreground">
                Obs: Tirar foto do código/tag da máquina para registrar o problema corretamente.
              </p>
            </div>
          </div>
          <Textarea
            value={errorObs}
            onChange={(e) => setErrorObs(e.target.value)}
            placeholder="Descreva o problema encontrado. Ex: Código da máquina GEL-001 — equipamento com falha na bomba de circulação..."
            className="min-h-[100px]"
          />
          <div className="flex gap-3">
            <Button variant="ghost" className="flex-1" onClick={() => setShowErrorForm(false)}>
              Cancelar
            </Button>
            <Button className="flex-1 bg-red-600 hover:bg-red-700 text-white" onClick={handleReportError}>
              <AlertCircle className="w-4 h-4 mr-2" /> Confirmar Erro e Finalizar
            </Button>
          </div>
        </div>
      )}

      {order.status === "completed" && (
        <div className="rounded-xl border border-green-500/30 bg-green-500/10 p-6 flex items-center gap-3">
          <CheckCircle2 className="w-8 h-8 text-green-400" />
          <div>
            <h3 className="text-lg font-bold text-green-400">Ordem Concluída</h3>
            <p className="text-sm text-muted-foreground">Esta OS foi finalizada com sucesso.</p>
          </div>
        </div>
      )}
    </UserLayout>
  );
}
