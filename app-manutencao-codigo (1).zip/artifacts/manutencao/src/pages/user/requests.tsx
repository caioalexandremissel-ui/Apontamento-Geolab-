import { UserLayout } from "@/components/layout/UserLayout";
import {
  useListEditRequests,
  getListEditRequestsQueryKey,
  useListConfirmations,
  useCreateEditRequest,
} from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Button } from "@/components/ui/button";
import { Plus, Clock, CheckCircle, XCircle, AlertTriangle, Wrench } from "lucide-react";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter,
} from "@/components/ui/dialog";
import {
  Form, FormControl, FormField, FormItem, FormLabel, FormMessage,
} from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";
import { useState } from "react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";

const requestSchema = z.object({
  confirmationId: z.coerce.number().min(1, "Selecione um apontamento"),
  reason: z.string().min(10, "Justificativa deve ter pelo menos 10 caracteres"),
});

export default function UserRequests() {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [isDialogOpen, setIsDialogOpen] = useState(false);

  const { data: requests, isLoading } = useListEditRequests(
    { requestedBy: user?.matricula }
  );

  const { data: confirmations } = useListConfirmations(
    { matricula: user?.matricula }
  );

  const createRequestMutation = useCreateEditRequest();

  const form = useForm<z.infer<typeof requestSchema>>({
    resolver: zodResolver(requestSchema),
    defaultValues: { confirmationId: 0, reason: "" },
  });

  const onSubmit = (data: z.infer<typeof requestSchema>) => {
    createRequestMutation.mutate(
      {
        data: {
          confirmationId: data.confirmationId,
          reason: data.reason,
        },
      },
      {
        onSuccess: () => {
          toast({ title: "Solicitação enviada", description: "Aguarde a análise do administrador." });
          queryClient.invalidateQueries({ queryKey: getListEditRequestsQueryKey({ requestedBy: user?.matricula }) });
          setIsDialogOpen(false);
          form.reset();
        },
        onError: () => {
          toast({ title: "Erro", description: "Não foi possível enviar a solicitação.", variant: "destructive" });
        },
      }
    );
  };

  const finishedConfs = (confirmations as any[])?.filter(
    (c: any) => c.status === "finished" || c.status === "edited"
  );

  const pendingRequests = (requests as any[])?.filter((r: any) => r.status === "pending") || [];
  const approvedRequests = (requests as any[])?.filter((r: any) => r.status === "approved") || [];
  const rejectedRequests = (requests as any[])?.filter((r: any) => r.status === "rejected") || [];

  return (
    <UserLayout>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Solicitações de Correção</h1>
          <p className="text-muted-foreground">Solicite correção em apontamentos finalizados.</p>
        </div>

        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="w-4 h-4 mr-2" />
              Nova Solicitação
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-md">
            <DialogHeader>
              <DialogTitle>Solicitar Correção</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4 pt-2">
                <FormField
                  control={form.control}
                  name="confirmationId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Apontamento *</FormLabel>
                      <Select onValueChange={field.onChange}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Selecione o apontamento" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {finishedConfs?.map((c: any) => (
                            <SelectItem key={c.id} value={c.id.toString()}>
                              {c.lineDescription || `ID ${c.id}`} — {c.startDate}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="reason"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Motivo da Correção *</FormLabel>
                      <FormControl>
                        <Textarea placeholder="Descreva o que precisa ser corrigido..." className="min-h-[100px]" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <DialogFooter>
                  <Button type="button" variant="ghost" onClick={() => setIsDialogOpen(false)}>Cancelar</Button>
                  <Button type="submit" disabled={createRequestMutation.isPending}>
                    {createRequestMutation.isPending ? "Enviando..." : "Enviar Solicitação"}
                  </Button>
                </DialogFooter>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      {isLoading ? (
        <div className="space-y-4">
          {[...Array(3)].map((_, i) => <Skeleton key={i} className="h-24 w-full" />)}
        </div>
      ) : (
        <div className="space-y-6">
          {/* Approved = Pendente Conserto — show prominently */}
          {approvedRequests.length > 0 && (
            <div>
              <h2 className="text-base font-semibold mb-3 flex items-center gap-2">
                <Wrench className="w-4 h-4 text-amber-400" />
                <span className="text-amber-400">Pendente Conserto</span>
                <Badge className="bg-amber-400/20 text-amber-400 border-amber-400/30">{approvedRequests.length}</Badge>
              </h2>
              <div className="space-y-3">
                {approvedRequests.map((r: any) => (
                  <Card key={r.id} className="border-amber-400/40 bg-amber-400/5">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1 flex-wrap">
                            <Badge className="bg-amber-400/20 text-amber-400 border-amber-400/30">
                              <Wrench className="w-3 h-3 mr-1" /> Aprovada — Pendente Conserto
                            </Badge>
                          </div>
                          <p className="text-sm text-foreground">{r.reason}</p>
                          {r.approvedBy && (
                            <p className="text-xs text-muted-foreground mt-1">Aprovado por: {r.approvedBy}</p>
                          )}
                          {r.createdAt && (
                            <p className="text-xs text-muted-foreground">
                              {format(new Date(r.createdAt), "dd/MM/yyyy HH:mm")}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="mt-3 p-2 rounded bg-amber-400/10 border border-amber-400/20 text-xs text-amber-300">
                        Sua solicitação foi aprovada. O apontamento será corrigido pelo administrador em breve.
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Pending */}
          {pendingRequests.length > 0 && (
            <div>
              <h2 className="text-base font-semibold mb-3 flex items-center gap-2">
                <Clock className="w-4 h-4 text-muted-foreground" />
                Aguardando Análise
                <Badge variant="outline">{pendingRequests.length}</Badge>
              </h2>
              <div className="space-y-3">
                {pendingRequests.map((r: any) => (
                  <Card key={r.id} className="border-border bg-card">
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <Badge variant="outline" className="text-muted-foreground">
                              <Clock className="w-3 h-3 mr-1" /> Em Análise
                            </Badge>
                          </div>
                          <p className="text-sm text-foreground">{r.reason}</p>
                          {r.createdAt && (
                            <p className="text-xs text-muted-foreground mt-1">
                              {format(new Date(r.createdAt), "dd/MM/yyyy HH:mm")}
                            </p>
                          )}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {/* Rejected */}
          {rejectedRequests.length > 0 && (
            <div>
              <h2 className="text-base font-semibold mb-3 flex items-center gap-2">
                <XCircle className="w-4 h-4 text-red-400" />
                Não Aprovadas
                <Badge variant="outline" className="text-red-400">{rejectedRequests.length}</Badge>
              </h2>
              <div className="space-y-3">
                {rejectedRequests.map((r: any) => (
                  <Card key={r.id} className="border-red-500/20 bg-red-500/5 opacity-70">
                    <CardContent className="p-4">
                      <div className="flex items-center gap-2 mb-1">
                        <Badge className="bg-red-500/20 text-red-400 border-red-500/30">
                          <XCircle className="w-3 h-3 mr-1" /> Não Aprovada
                        </Badge>
                      </div>
                      <p className="text-sm text-foreground">{r.reason}</p>
                      {r.createdAt && (
                        <p className="text-xs text-muted-foreground mt-1">
                          {format(new Date(r.createdAt), "dd/MM/yyyy HH:mm")}
                        </p>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          )}

          {!requests || (requests as any[]).length === 0 ? (
            <Card className="bg-card border-border">
              <CardContent className="p-8 text-center text-muted-foreground">
                <AlertTriangle className="w-8 h-8 mx-auto mb-3 opacity-30" />
                Nenhuma solicitação de correção enviada ainda.
              </CardContent>
            </Card>
          ) : null}
        </div>
      )}
    </UserLayout>
  );
}
