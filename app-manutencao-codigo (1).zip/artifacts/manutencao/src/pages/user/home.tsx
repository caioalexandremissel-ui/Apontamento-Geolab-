import { UserLayout } from "@/components/layout/UserLayout";
import { 
  useListServiceOrders, 
  getListServiceOrdersQueryKey 
} from "@workspace/api-client-react";
import { useAuth } from "@/contexts/AuthContext";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Link } from "wouter";
import { FileText, Wrench, AlertCircle, Clock } from "lucide-react";

export default function UserHome() {
  const { user } = useAuth();
  
  const { data: orders, isLoading } = useListServiceOrders(
    { assignedTo: user?.matricula, status: "open" }
  );

  if (isLoading) {
    return (
      <UserLayout>
        <div className="space-y-4">
          <Skeleton className="h-8 w-64 mb-6" />
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-32 w-full rounded-xl" />
          ))}
        </div>
      </UserLayout>
    );
  }

  return (
    <UserLayout>
      <div className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight">Ordens de Serviço</h1>
        <p className="text-muted-foreground">Selecione uma ordem para iniciar o apontamento.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {orders && orders.length > 0 ? (
          orders.map((os) => (
            <Link key={os.id} href={`/user/ordens/${os.id}`}>
              <Card className="hover:bg-secondary/50 transition-colors cursor-pointer h-full flex flex-col border-border group relative overflow-hidden">
                <div className="absolute top-0 left-0 w-1 h-full bg-primary group-hover:w-2 transition-all" />
                <CardHeader className="pb-2">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-xl font-mono text-primary">{os.orderNumber}</CardTitle>
                      <div className="text-xs text-muted-foreground mt-1 flex items-center gap-1">
                        {os.type === 'preventive' ? (
                          <><Clock className="w-3 h-3" /> Preventiva</>
                        ) : (
                          <><AlertCircle className="w-3 h-3 text-destructive" /> Corretiva</>
                        )}
                      </div>
                    </div>
                    <Badge variant={os.status === 'in_progress' ? 'default' : 'outline'}>
                      {os.status === 'open' ? 'Aberta' : os.status === 'in_progress' ? 'Em Andamento' : 'Concluída'}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent className="flex-1 flex flex-col justify-between">
                  <p className="text-sm line-clamp-2 mb-4">{os.description}</p>
                  
                  <div className="space-y-2 mt-auto">
                    {os.equipment && (
                      <div className="text-xs flex items-center gap-2 text-muted-foreground">
                        <Wrench className="w-3 h-3" />
                        <span className="truncate">{os.equipment}</span>
                      </div>
                    )}
                    <div className="text-xs flex items-center gap-2 text-muted-foreground">
                      <FileText className="w-3 h-3" />
                      <span>{os.lines?.length || 0} Operações</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))
        ) : (
          <div className="col-span-full py-12 text-center border rounded-lg bg-card/50">
            <CheckCircle className="w-12 h-12 text-green-500 mx-auto mb-4" />
            <h3 className="text-lg font-medium">Tudo limpo</h3>
            <p className="text-muted-foreground mt-1">Não há ordens de serviço pendentes para você no momento.</p>
          </div>
        )}
      </div>
    </UserLayout>
  );
}

function CheckCircle(props: React.ComponentProps<"svg">) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14" />
      <polyline points="22 4 12 14.01 9 11.01" />
    </svg>
  );
}
