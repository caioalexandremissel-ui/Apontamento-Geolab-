import { UserLayout } from "@/components/layout/UserLayout";
import {
  useGetServiceOrderLine,
  getGetServiceOrderLineQueryKey,
  getGetServiceOrderQueryKey,
  useCreateConfirmation,
  useFinishConfirmation,
  usePauseConfirmation,
  useResumeConfirmation,
  useListRootCauses,
} from "@workspace/api-client-react";
import { useParams, Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  ArrowLeft, Play, Square, AlertTriangle, Info, Camera, X, Image,
  Pause, RotateCcw,
} from "lucide-react";
import { useAuth } from "@/contexts/AuthContext";
import { useState, useEffect, useRef } from "react";
import { format } from "date-fns";
import { useQueryClient } from "@tanstack/react-query";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useToast } from "@/hooks/use-toast";

const finishSchema = z.object({
  observation: z.string().min(1, "Observação é obrigatória"),
  coWorkerMatricula: z.string().optional(),
  rootCauseId: z.coerce.number().optional(),
  justification: z.string().optional(),
});

interface PhotoEntry {
  type: "machine_code" | "before" | "after";
  data: string;
  label: string;
}

function compressImage(file: File, maxWidth = 800): Promise<string> {
  return new Promise((resolve) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const img = document.createElement("img");
      img.onload = () => {
        const canvas = document.createElement("canvas");
        const ratio = Math.min(maxWidth / img.width, 1);
        canvas.width = img.width * ratio;
        canvas.height = img.height * ratio;
        const ctx = canvas.getContext("2d")!;
        ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
        resolve(canvas.toDataURL("image/jpeg", 0.7));
      };
      img.src = e.target?.result as string;
    };
    reader.readAsDataURL(file);
  });
}

export default function UserAppointmentForm() {
  const params = useParams();
  const orderId = parseInt(params.id || "0", 10);
  const lineId = parseInt(params.lineId || "0", 10);
  const [, setLocation] = useLocation();
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const [elapsedTime, setElapsedTime] = useState(0);
  const [photos, setPhotos] = useState<PhotoEntry[]>([]);
  const machinePhotoRef = useRef<HTMLInputElement>(null);
  const beforePhotoRef = useRef<HTMLInputElement>(null);
  const afterPhotoRef = useRef<HTMLInputElement>(null);

  const { data: line, isLoading } = useGetServiceOrderLine(lineId, {
    query: { queryKey: getGetServiceOrderLineQueryKey(lineId), enabled: !!lineId },
  });

  const { data: rootCauses } = useListRootCauses();
  const createMutation = useCreateConfirmation();
  const finishMutation = useFinishConfirmation();
  const pauseMutation = usePauseConfirmation();
  const resumeMutation = useResumeConfirmation();

  const activeConfirmation = line?.confirmations?.find(
    (c: any) =>
      (c.status === "started" || c.status === "paused") &&
      c.employeeMatricula === user?.matricula
  ) as any;

  const isPaused = activeConfirmation?.status === "paused";

  const form = useForm<z.infer<typeof finishSchema>>({
    resolver: zodResolver(finishSchema),
    defaultValues: { observation: "", coWorkerMatricula: "", justification: "" },
  });

  useEffect(() => {
    let interval: NodeJS.Timeout;
    if (activeConfirmation?.startDate && activeConfirmation?.startTime && !isPaused) {
      const startDateTime = new Date(`${activeConfirmation.startDate}T${activeConfirmation.startTime}`);
      const pausedMinutes = activeConfirmation.totalPausedMinutes || 0;
      const update = () => {
        const diffMs = Date.now() - startDateTime.getTime() - pausedMinutes * 60 * 1000;
        const diff = Math.floor(diffMs / 1000);
        setElapsedTime(diff > 0 ? diff : 0);
      };
      update();
      interval = setInterval(update, 1000);
    }
    return () => clearInterval(interval);
  }, [activeConfirmation, isPaused]);

  const formatTime = (s: number) => {
    const h = Math.floor(s / 3600);
    const m = Math.floor((s % 3600) / 60);
    const sec = s % 60;
    return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`;
  };

  const handlePhotoCapture = async (
    e: React.ChangeEvent<HTMLInputElement>,
    type: PhotoEntry["type"],
    label: string
  ) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const data = await compressImage(file);
    setPhotos((prev) => {
      const filtered = prev.filter((p) => p.type !== type);
      return [...filtered, { type, data, label }];
    });
    e.target.value = "";
  };

  const removePhoto = (type: PhotoEntry["type"]) => {
    setPhotos((prev) => prev.filter((p) => p.type !== type));
  };

  const handleStart = () => {
    const now = new Date();
    createMutation.mutate(
      {
        data: {
          lineId,
          employeeMatricula: user?.matricula || "",
          startDate: format(now, "yyyy-MM-dd"),
          startTime: format(now, "HH:mm:ss"),
        },
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetServiceOrderLineQueryKey(lineId) });
          queryClient.invalidateQueries({ queryKey: getGetServiceOrderQueryKey(orderId) });
          toast({ title: "Apontamento Iniciado", description: "O tempo começou a ser contabilizado." });
        },
      }
    );
  };

  const handlePause = () => {
    if (!activeConfirmation) return;
    pauseMutation.mutate(
      { id: activeConfirmation.id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetServiceOrderLineQueryKey(lineId) });
          queryClient.invalidateQueries({ queryKey: getGetServiceOrderQueryKey(orderId) });
          toast({ title: "Apontamento Pausado", description: "O tempo foi interrompido. Retome quando estiver pronto." });
        },
      }
    );
  };

  const handleResume = () => {
    if (!activeConfirmation) return;
    resumeMutation.mutate(
      { id: activeConfirmation.id },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetServiceOrderLineQueryKey(lineId) });
          queryClient.invalidateQueries({ queryKey: getGetServiceOrderQueryKey(orderId) });
          toast({ title: "Apontamento Retomado", description: "O tempo voltou a ser contabilizado." });
        },
      }
    );
  };

  const onFinishSubmit = (data: z.infer<typeof finishSchema>) => {
    if (!activeConfirmation) return;
    const expectedHours = line?.expectedTime || 0;
    const elapsedHours = elapsedTime / 3600;
    if (elapsedHours > expectedHours && !data.justification) {
      toast({
        title: "Justificativa Obrigatória",
        description: `O tempo excedeu o previsto (${expectedHours}h). Preencha a justificativa.`,
        variant: "destructive",
      });
      return;
    }
    const now = new Date();
    finishMutation.mutate(
      {
        id: activeConfirmation.id,
        data: {
          ...data,
          endDate: format(now, "yyyy-MM-dd"),
          endTime: format(now, "HH:mm:ss"),
          photos: photos.length > 0 ? JSON.stringify(photos.map(({ type, data }) => ({ type, data }))) : null,
        },
      },
      {
        onSuccess: () => {
          queryClient.invalidateQueries({ queryKey: getGetServiceOrderLineQueryKey(lineId) });
          queryClient.invalidateQueries({ queryKey: getGetServiceOrderQueryKey(orderId) });
          toast({ title: "Apontamento Finalizado", description: "Trabalho registrado com sucesso." });
          setLocation(`/user/ordens/${orderId}`);
        },
      }
    );
  };

  if (isLoading) {
    return (
      <UserLayout>
        <div className="space-y-4">
          <Skeleton className="h-8 w-64 mb-6" />
          <Skeleton className="h-64 w-full" />
        </div>
      </UserLayout>
    );
  }

  if (!line) return <UserLayout><div className="p-8 text-center text-muted-foreground">Operação não encontrada.</div></UserLayout>;

  const isOvertime = line.expectedTime ? elapsedTime / 3600 > line.expectedTime : false;

  return (
    <UserLayout>
      {/* Hidden file inputs */}
      <input ref={machinePhotoRef} type="file" accept="image/*" capture="environment" className="hidden"
        onChange={(e) => handlePhotoCapture(e, "machine_code", "Código / Tag da Máquina")} />
      <input ref={beforePhotoRef} type="file" accept="image/*" capture="environment" className="hidden"
        onChange={(e) => handlePhotoCapture(e, "before", "Foto Antes")} />
      <input ref={afterPhotoRef} type="file" accept="image/*" capture="environment" className="hidden"
        onChange={(e) => handlePhotoCapture(e, "after", "Foto Depois")} />

      <div className="mb-6">
        <Link href={`/user/ordens/${orderId}`} className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground mb-4">
          <ArrowLeft className="w-4 h-4 mr-2" />
          Voltar para Ordem
        </Link>
        <h1 className="text-2xl font-bold tracking-tight text-primary font-mono">OP {line.opNumber}</h1>
        <p className="text-foreground text-lg">{line.description}</p>
      </div>

      {!activeConfirmation ? (
        <div className="space-y-4">
          {/* Machine photo capture BEFORE starting */}
          <Card className="bg-card border-border">
            <CardHeader className="pb-3">
              <CardTitle className="text-base flex items-center gap-2">
                <Camera className="w-4 h-4 text-primary" /> Identificação da Máquina
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-3">
                Tire uma foto do código ou tag da máquina para confirmar o equipamento correto.
              </p>
              {photos.find((p) => p.type === "machine_code") ? (
                <div className="relative inline-block">
                  <img
                    src={photos.find((p) => p.type === "machine_code")!.data}
                    alt="Código da máquina"
                    className="h-32 rounded-lg border border-border object-cover"
                  />
                  <button
                    onClick={() => removePhoto("machine_code")}
                    className="absolute -top-2 -right-2 bg-destructive text-white rounded-full w-5 h-5 flex items-center justify-center"
                  >
                    <X className="w-3 h-3" />
                  </button>
                </div>
              ) : (
                <Button variant="outline" onClick={() => machinePhotoRef.current?.click()} className="gap-2">
                  <Camera className="w-4 h-4" /> Tirar Foto do Código
                </Button>
              )}
            </CardContent>
          </Card>

          <Card className="bg-card border-border shadow-lg">
            <CardContent className="p-8 flex flex-col items-center justify-center text-center space-y-6">
              <div className="w-20 h-20 bg-secondary rounded-full flex items-center justify-center">
                <Play className="w-10 h-10 text-primary ml-2" />
              </div>
              <div>
                <h2 className="text-2xl font-bold mb-2">Pronto para iniciar?</h2>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Ao clicar em iniciar, o sistema registrará a hora exata do começo do trabalho.
                </p>
              </div>
              {line.expectedTime && (
                <div className="bg-secondary/50 px-4 py-2 rounded-md flex items-center gap-2 text-sm">
                  <Info className="w-4 h-4 text-primary" /> Tempo esperado: <strong>{line.expectedTime}h</strong>
                </div>
              )}
              <Button size="lg" className="w-full max-w-sm text-lg h-14" onClick={handleStart} disabled={createMutation.isPending}>
                <Play className="w-5 h-5 mr-2" /> Iniciar Apontamento
              </Button>
            </CardContent>
          </Card>
        </div>
      ) : (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Timer card */}
          <Card className={`border-l-4 lg:col-span-1 h-fit ${isPaused ? "bg-amber-900/20 border-l-amber-400 border-amber-400/20" : "bg-card border-l-primary border-border"}`}>
            <CardContent className="p-6 flex flex-col items-center justify-center text-center space-y-4">
              <div className="flex items-center gap-2">
                <div className="text-sm font-bold uppercase tracking-wider text-muted-foreground">Tempo Decorrido</div>
                {isPaused && (
                  <Badge className="bg-amber-400/20 text-amber-400 border-amber-400/30 text-xs">Pausado</Badge>
                )}
              </div>
              <div className={`text-5xl font-mono font-bold tracking-tighter ${isPaused ? "text-amber-400" : isOvertime ? "text-destructive" : "text-primary"}`}>
                {formatTime(elapsedTime)}
              </div>
              <div className="text-sm text-muted-foreground">Iniciado às {activeConfirmation.startTime}</div>
              {isOvertime && !isPaused && (
                <div className="text-xs text-destructive flex items-center gap-1 bg-destructive/10 px-2 py-1 rounded">
                  <AlertTriangle className="w-3 h-3" /> Tempo excedido
                </div>
              )}

              {/* Pause / Resume button */}
              {isPaused ? (
                <Button
                  className="w-full bg-green-600 hover:bg-green-700 text-white"
                  onClick={handleResume}
                  disabled={resumeMutation.isPending}
                >
                  <RotateCcw className="w-4 h-4 mr-2" />
                  {resumeMutation.isPending ? "Retomando..." : "Retomar Trabalho"}
                </Button>
              ) : (
                <Button
                  variant="outline"
                  className="w-full border-amber-400/40 text-amber-400 hover:bg-amber-400/10"
                  onClick={handlePause}
                  disabled={pauseMutation.isPending}
                >
                  <Pause className="w-4 h-4 mr-2" />
                  {pauseMutation.isPending ? "Pausando..." : "Pausar"}
                </Button>
              )}
            </CardContent>
          </Card>

          {/* Finish form */}
          <Card className={`border-border lg:col-span-2 ${isPaused ? "opacity-60 pointer-events-none" : "bg-card"}`}>
            <CardHeader className="pb-4 border-b border-border">
              <CardTitle className="text-lg">Finalizar Apontamento</CardTitle>
              {isPaused && (
                <p className="text-xs text-amber-400 mt-1">Retome o apontamento para finalizar.</p>
              )}
            </CardHeader>
            <CardContent className="pt-6">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onFinishSubmit)} className="space-y-5">
                  {/* Photos section */}
                  <div>
                    <p className="text-sm font-medium mb-2 flex items-center gap-1">
                      <Image className="w-4 h-4 text-primary" /> Fotos (Opcional)
                    </p>
                    <div className="flex gap-3 flex-wrap">
                      {(["before", "after"] as const).map((type) => {
                        const labels = { before: "Antes", after: "Depois" };
                        const refs = { before: beforePhotoRef, after: afterPhotoRef };
                        const photo = photos.find((p) => p.type === type);
                        return photo ? (
                          <div key={type} className="relative">
                            <img src={photo.data} alt={labels[type]} className="h-20 w-20 rounded-lg border border-border object-cover" />
                            <div className="absolute bottom-0 left-0 right-0 bg-black/50 text-white text-xs text-center rounded-b-lg py-0.5">
                              {labels[type]}
                            </div>
                            <button onClick={() => removePhoto(type)} className="absolute -top-2 -right-2 bg-destructive text-white rounded-full w-5 h-5 flex items-center justify-center">
                              <X className="w-3 h-3" />
                            </button>
                          </div>
                        ) : (
                          <button
                            key={type}
                            type="button"
                            onClick={() => refs[type].current?.click()}
                            className="h-20 w-20 border-2 border-dashed border-border rounded-lg flex flex-col items-center justify-center gap-1 hover:border-primary transition-colors text-muted-foreground hover:text-primary"
                          >
                            <Camera className="w-5 h-5" />
                            <span className="text-xs">{labels[type]}</span>
                          </button>
                        );
                      })}
                    </div>
                  </div>

                  <FormField
                    control={form.control}
                    name="observation"
                    render={({ field }) => (
                      <FormItem>
                        <div className="flex justify-between items-center mb-1">
                          <FormLabel>Observação do Trabalho Realizado *</FormLabel>
                          <Button type="button" variant="outline" size="sm" className="h-7 text-xs"
                            onClick={() => form.setValue("observation", "Trabalho preventivo realizado com sucesso. Tudo OK.")}>
                            Preencher "Tudo OK"
                          </Button>
                        </div>
                        <FormControl>
                          <Textarea placeholder="Descreva o que foi feito..." className="min-h-[90px]" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
                    <FormField
                      control={form.control}
                      name="coWorkerMatricula"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Matrícula do Ajudante (Opcional)</FormLabel>
                          <FormControl><Input placeholder="Ex: 123456" {...field} /></FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                    <FormField
                      control={form.control}
                      name="rootCauseId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Causa Raiz</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value?.toString() || ""}>
                            <FormControl>
                              <SelectTrigger><SelectValue placeholder="Selecione se houver defeito" /></SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {rootCauses?.map((cause) => (
                                <SelectItem key={cause.id} value={cause.id.toString()}>{cause.code} - {cause.description}</SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {isOvertime && (
                    <FormField
                      control={form.control}
                      name="justification"
                      render={({ field }) => (
                        <FormItem className="bg-destructive/5 p-4 rounded-md border border-destructive/20">
                          <FormLabel className="text-destructive flex items-center gap-2">
                            <AlertTriangle className="w-4 h-4" /> Justificativa de Tempo Excedente (Obrigatório)
                          </FormLabel>
                          <FormControl>
                            <Textarea placeholder="Explique por que a operação levou mais tempo..." {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  )}

                  <div className="pt-4 border-t border-border">
                    <Button type="submit" className="w-full h-12 text-lg bg-green-600 hover:bg-green-700 text-white" disabled={finishMutation.isPending || isPaused}>
                      <Square className="w-5 h-5 mr-2 fill-current" />
                      {finishMutation.isPending ? "Finalizando..." : "Finalizar Apontamento"}
                    </Button>
                  </div>
                </form>
              </Form>
            </CardContent>
          </Card>
        </div>
      )}
    </UserLayout>
  );
}
