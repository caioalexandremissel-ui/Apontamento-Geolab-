import { Router } from "express";
import { db, signaturesTable } from "@workspace/db";
import { eq, and } from "drizzle-orm";

const router = Router();

function mapSignature(s: any) {
  return {
    id: s.id,
    serviceOrderId: s.serviceOrderId,
    signerType: s.signerType,
    signerName: s.signerName,
    signerMatricula: s.signerMatricula,
    signatureData: s.signatureData,
    signedAt: s.signedAt,
  };
}

router.get("/service-orders/:id/signatures", async (req, res) => {
  try {
    const serviceOrderId = parseInt(req.params.id);
    const sigs = await db.select().from(signaturesTable).where(eq(signaturesTable.serviceOrderId, serviceOrderId));
    return res.json(sigs.map(mapSignature));
  } catch (err) {
    req.log.error({ err }, "Error listing signatures");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/service-orders/:id/signatures", async (req, res) => {
  try {
    const serviceOrderId = parseInt(req.params.id);
    const { signerType, signerName, signerMatricula, signatureData } = req.body;

    if (!signerType || !signerName || !signatureData) {
      return res.status(400).json({ error: "signerType, signerName e signatureData são obrigatórios" });
    }

    const VALID_TYPES = ["executor", "area_responsible", "immediate_supervisor"];
    if (!VALID_TYPES.includes(signerType)) {
      return res.status(400).json({ error: "signerType inválido" });
    }

    // Delete existing signature of same type for this order (upsert)
    await db
      .delete(signaturesTable)
      .where(
        and(
          eq(signaturesTable.serviceOrderId, serviceOrderId),
          eq(signaturesTable.signerType, signerType)
        )
      );

    const [sig] = await db
      .insert(signaturesTable)
      .values({ serviceOrderId, signerType, signerName, signerMatricula, signatureData })
      .returning();

    return res.status(201).json(mapSignature(sig));
  } catch (err) {
    req.log.error({ err }, "Error saving signature");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/service-orders/:id/signatures/:signerType", async (req, res) => {
  try {
    const serviceOrderId = parseInt(req.params.id);
    const { signerType } = req.params;
    await db
      .delete(signaturesTable)
      .where(
        and(
          eq(signaturesTable.serviceOrderId, serviceOrderId),
          eq(signaturesTable.signerType, signerType)
        )
      );
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error deleting signature");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
