import { Router } from "express";
import { db, confirmationsTable, serviceOrdersTable, editRequestsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/dashboard/summary", async (req, res) => {
  try {
    const orders = await db.select().from(serviceOrdersTable);
    const confirmations = await db.select().from(confirmationsTable);
    const editRequests = await db.select().from(editRequestsTable);
    const users = await db.select().from(usersTable);

    const today = new Date().toISOString().split("T")[0];

    const totalOrders = orders.length;
    const openOrders = orders.filter((o) => o.status === "open" || o.status === "in_progress").length;
    const completedToday = confirmations.filter((c) => c.status === "finished" && c.endDate === today).length;
    const pendingEditRequests = editRequests.filter((r) => r.status === "pending").length;
    const overtimeConfirmations = confirmations.filter((c) => c.status === "overtime_pending").length;
    const totalEmployees = users.filter((u) => u.role === "user").length;
    const recentOrders = orders
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 5)
      .map((o) => ({
        id: o.id,
        orderNumber: o.orderNumber,
        description: o.description,
        type: o.type,
        status: o.status,
        equipment: o.equipment,
        costCenter: o.costCenter,
        location: o.location,
        expectedDuration: o.expectedDuration ? Number(o.expectedDuration) : null,
        openDate: o.openDate,
        center: o.center,
        area: o.area,
        activityType: o.activityType,
        createdAt: o.createdAt,
        lines: [],
      }));

    return res.json({
      totalOrders,
      openOrders,
      completedToday,
      pendingEditRequests,
      overtimeConfirmations,
      totalEmployees,
      recentOrders,
    });
  } catch (err) {
    req.log.error({ err }, "Error getting dashboard summary");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/dashboard/recent-activity", async (req, res) => {
  try {
    const confirmations = await db.select().from(confirmationsTable);
    const users = await db.select().from(usersTable);
    const orders = await db.select().from(serviceOrdersTable);

    const sorted = [...confirmations]
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
      .slice(0, 20);

    const activity = sorted.map((c) => {
      const user = users.find((u) => u.matricula === c.employeeMatricula);
      let type = "apontamento";
      let description = "";
      if (c.status === "started") {
        type = "inicio";
        description = "Iniciou apontamento";
      } else if (c.status === "finished") {
        type = "conclusao";
        description = "Finalizou apontamento";
      } else if (c.status === "overtime_pending") {
        type = "hora_extra";
        description = "Apontamento com hora extra pendente de justificativa";
      } else if (c.status === "edited") {
        type = "edicao";
        description = "Apontamento editado";
      }

      return {
        id: c.id,
        type,
        description,
        employeeName: user?.name || c.employeeMatricula,
        employeeMatricula: c.employeeMatricula,
        orderNumber: null as string | null,
        timestamp: c.createdAt.toISOString(),
      };
    });

    return res.json(activity);
  } catch (err) {
    req.log.error({ err }, "Error getting recent activity");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
