import { Router } from "express";
import { db, confirmationsTable, serviceOrderLinesTable, serviceOrdersTable, usersTable } from "@workspace/db";
import { eq, inArray } from "drizzle-orm";

const router = Router();

router.get("/export/confirmations", async (req, res) => {
  try {
    const { startDate, endDate, serviceOrderId, matricula } = req.query;

    let confs = await db
      .select()
      .from(confirmationsTable)
      .where(inArray(confirmationsTable.status, ["finished", "edited"]));

    if (matricula) confs = confs.filter((c) => c.employeeMatricula === (matricula as string));
    if (startDate) confs = confs.filter((c) => c.startDate != null && c.startDate >= (startDate as string));
    if (endDate) confs = confs.filter((c) => c.startDate != null && c.startDate <= (endDate as string));

    if (serviceOrderId) {
      const lines = await db
        .select()
        .from(serviceOrderLinesTable)
        .where(eq(serviceOrderLinesTable.serviceOrderId, parseInt(serviceOrderId as string)));
      const lineIds = new Set(lines.map((l) => l.id));
      confs = confs.filter((c) => lineIds.has(c.lineId));
    }

    const allLines = await db.select().from(serviceOrderLinesTable);
    const allOrders = await db.select().from(serviceOrdersTable);
    const allUsers = await db.select().from(usersTable);

    const data = confs.map((c) => {
      const line = allLines.find((l) => l.id === c.lineId);
      const order = line ? allOrders.find((o) => o.id === line.serviceOrderId) : null;
      const user = allUsers.find((u) => u.matricula === c.employeeMatricula);

      return {
        orderNumber: order?.orderNumber ?? "",
        centTrab: line?.centTrab ?? "",
        center: order?.center ?? "",
        activityType: order?.activityType ?? "",
        employeeMatricula: c.employeeMatricula,
        employeeName: user?.name ?? "",
        coWorkerMatricula: c.coWorkerMatricula ?? null,
        startDate: c.startDate ?? "",
        startTime: c.startTime ?? "",
        endDate: c.endDate ?? "",
        endTime: c.endTime ?? "",
        realWork: c.realWork != null ? Number(c.realWork) : 0,
        observation: c.observation ?? "",
        justification: c.justification ?? null,
        status: c.status,
      };
    });

    return res.json({ count: data.length, data });
  } catch (err) {
    req.log.error({ err }, "Error exporting confirmations");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
