import { Router } from "express";
import { db, serviceOrderLinesTable, confirmationsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

async function mapLine(l: any, confirmations: any[] = []) {
  let assignedName: string | null = null;
  if (l.assignedMatricula) {
    try {
      const [user] = await db.select().from(usersTable).where(eq(usersTable.matricula, l.assignedMatricula));
      if (user) assignedName = user.name;
    } catch {}
  }
  return {
    id: l.id,
    serviceOrderId: l.serviceOrderId,
    opNumber: l.opNumber,
    subOp: l.subOp,
    centTrab: l.centTrab,
    cen: l.cen,
    description: l.description,
    expectedTime: l.expectedTime ? Number(l.expectedTime) : null,
    cap: l.cap ? Number(l.cap) : null,
    assignedMatricula: l.assignedMatricula,
    assignedName,
    confirmations,
  };
}

router.get("/service-order-lines", async (req, res) => {
  try {
    const lines = await db.select().from(serviceOrderLinesTable);
    const mapped = await Promise.all(lines.map((l) => mapLine(l)));
    return res.json(mapped);
  } catch (err) {
    req.log.error({ err }, "Error listing service order lines");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/service-order-lines", async (req, res) => {
  try {
    const { serviceOrderId, opNumber, subOp, centTrab, cen, description, expectedTime, cap, assignedMatricula } = req.body;
    if (!serviceOrderId || !opNumber || !description) {
      return res.status(400).json({ error: "serviceOrderId, opNumber e description são obrigatórios" });
    }
    const [line] = await db
      .insert(serviceOrderLinesTable)
      .values({ serviceOrderId, opNumber, subOp, centTrab, cen, description, expectedTime, cap, assignedMatricula })
      .returning();
    return res.json(await mapLine(line));
  } catch (err) {
    req.log.error({ err }, "Error creating service order line");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/service-order-lines/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [line] = await db.select().from(serviceOrderLinesTable).where(eq(serviceOrderLinesTable.id, id));
    if (!line) return res.status(404).json({ error: "Linha não encontrada" });
    const confirmations = await db
      .select()
      .from(confirmationsTable)
      .where(eq(confirmationsTable.lineId, id));
    return res.json(await mapLine(line, confirmations));
  } catch (err) {
    req.log.error({ err }, "Error getting service order line");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.put("/service-order-lines/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { opNumber, description, expectedTime, centTrab, cen, assignedMatricula } = req.body;
    const updates: Record<string, any> = {};
    if (opNumber !== undefined) updates.opNumber = opNumber;
    if (description !== undefined) updates.description = description;
    if (expectedTime !== undefined) updates.expectedTime = expectedTime;
    if (centTrab !== undefined) updates.centTrab = centTrab;
    if (cen !== undefined) updates.cen = cen;
    if (assignedMatricula !== undefined) updates.assignedMatricula = assignedMatricula || null;

    const [line] = await db
      .update(serviceOrderLinesTable)
      .set(updates)
      .where(eq(serviceOrderLinesTable.id, id))
      .returning();
    if (!line) return res.status(404).json({ error: "Linha não encontrada" });
    return res.json(await mapLine(line));
  } catch (err) {
    req.log.error({ err }, "Error updating service order line");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/service-order-lines/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(serviceOrderLinesTable).where(eq(serviceOrderLinesTable.id, id));
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error deleting service order line");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
