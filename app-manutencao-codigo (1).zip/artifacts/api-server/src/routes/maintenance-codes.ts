import { Router } from "express";
import { db, maintenanceCodesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/maintenance-codes", async (req, res) => {
  try {
    const codes = await db.select().from(maintenanceCodesTable);
    return res.json(codes.map((c) => ({ id: c.id, code: c.code, name: c.name, type: c.type })));
  } catch (err) {
    req.log.error({ err }, "Error listing maintenance codes");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/maintenance-codes", async (req, res) => {
  try {
    const { code, name, type = "preventive" } = req.body;
    if (!code || !name) {
      return res.status(400).json({ error: "code e name são obrigatórios" });
    }
    const [mc] = await db.insert(maintenanceCodesTable).values({ code, name, type }).returning();
    return res.status(201).json({ id: mc.id, code: mc.code, name: mc.name, type: mc.type });
  } catch (err: any) {
    req.log.error({ err }, "Error creating maintenance code");
    if (err.code === "23505") return res.status(409).json({ error: "Código já cadastrado" });
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.put("/maintenance-codes/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { code, name, type } = req.body;
    const updates: Record<string, any> = {};
    if (code !== undefined) updates.code = code;
    if (name !== undefined) updates.name = name;
    if (type !== undefined) updates.type = type;

    const [mc] = await db.update(maintenanceCodesTable).set(updates).where(eq(maintenanceCodesTable.id, id)).returning();
    if (!mc) return res.status(404).json({ error: "Código não encontrado" });
    return res.json({ id: mc.id, code: mc.code, name: mc.name, type: mc.type });
  } catch (err) {
    req.log.error({ err }, "Error updating maintenance code");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/maintenance-codes/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(maintenanceCodesTable).where(eq(maintenanceCodesTable.id, id));
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error deleting maintenance code");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
