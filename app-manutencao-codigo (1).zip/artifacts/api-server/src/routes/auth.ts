import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.post("/auth/login", async (req, res) => {
  try {
    const { matricula, password } = req.body;
    if (!matricula || !password) {
      return res.status(400).json({ error: "Matrícula e senha são obrigatórios" });
    }

    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.matricula, matricula));

    if (!user || user.password !== password) {
      return res.status(401).json({ error: "Matrícula ou senha inválidos" });
    }

    if (!user.active) {
      return res.status(401).json({ error: "Usuário inativo" });
    }

    (req as any).session = (req as any).session || {};
    (req as any).session.userId = user.id;
    (req as any).session.matricula = user.matricula;
    (req as any).session.role = user.role;

    const token = Buffer.from(`${user.matricula}:${user.id}:${user.role}`).toString("base64");

    return res.json({
      user: {
        id: user.id,
        matricula: user.matricula,
        name: user.name,
        role: user.role,
        active: user.active,
        centTrab: user.centTrab,
        createdAt: user.createdAt,
      },
      token,
    });
  } catch (err) {
    req.log.error({ err }, "Login error");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/auth/logout", (req, res) => {
  return res.json({ success: true });
});

router.get("/auth/me", async (req, res) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader?.startsWith("Bearer ")) {
      return res.status(401).json({ error: "Não autenticado" });
    }

    const token = authHeader.replace("Bearer ", "");
    let matricula: string;
    try {
      const decoded = Buffer.from(token, "base64").toString("utf-8");
      matricula = decoded.split(":")[0];
    } catch {
      return res.status(401).json({ error: "Token inválido" });
    }

    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.matricula, matricula));

    if (!user) {
      return res.status(401).json({ error: "Usuário não encontrado" });
    }

    return res.json({
      id: user.id,
      matricula: user.matricula,
      name: user.name,
      role: user.role,
      active: user.active,
      centTrab: user.centTrab,
      createdAt: user.createdAt,
    });
  } catch (err) {
    req.log.error({ err }, "Get me error");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
