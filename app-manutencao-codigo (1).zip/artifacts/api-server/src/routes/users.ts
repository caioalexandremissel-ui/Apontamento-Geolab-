import { Router } from "express";
import { db, usersTable } from "@workspace/db";
import { eq, count, and } from "drizzle-orm";

const router = Router();

router.get("/users/summary", async (req, res) => {
  try {
    const all = await db.select().from(usersTable);
    const total = all.length;
    const admins = all.filter((u) => u.role === "admin").length;
    const users = all.filter((u) => u.role === "user").length;
    const active = all.filter((u) => u.active).length;
    const inactive = all.filter((u) => !u.active).length;
    return res.json({ total, admins, users, active, inactive });
  } catch (err) {
    req.log.error({ err }, "Error getting users summary");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/users", async (req, res) => {
  try {
    const { role, active } = req.query;
    let users = await db.select().from(usersTable);
    if (role) users = users.filter((u) => u.role === role);
    if (active !== undefined) users = users.filter((u) => u.active === (active === "true"));
    return res.json(
      users.map((u) => ({
        id: u.id,
        matricula: u.matricula,
        name: u.name,
        role: u.role,
        active: u.active,
        centTrab: u.centTrab,
        createdAt: u.createdAt,
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Error listing users");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/users", async (req, res) => {
  try {
    const { matricula, name, role = "user", active = true, centTrab } = req.body;
    if (!matricula || !name) {
      return res.status(400).json({ error: "Matrícula e nome são obrigatórios" });
    }
    const [user] = await db
      .insert(usersTable)
      .values({ matricula, name, role, active, centTrab, password: matricula })
      .returning();
    return res.status(201).json({
      id: user.id,
      matricula: user.matricula,
      name: user.name,
      role: user.role,
      active: user.active,
      centTrab: user.centTrab,
      createdAt: user.createdAt,
    });
  } catch (err: any) {
    req.log.error({ err }, "Error creating user");
    if (err.code === "23505") {
      return res.status(409).json({ error: "Matrícula já cadastrada" });
    }
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/users/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, id));
    if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
    return res.json({
      id: user.id,
      matricula: user.matricula,
      name: user.name,
      role: user.role,
      active: user.active,
      centTrab: user.centTrab,
      createdAt: user.createdAt,
    });
  } catch (err) {
    req.log.error({ err }, "Error getting user");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.put("/users/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { name, role, active, centTrab, password } = req.body;
    const updates: Record<string, any> = {};
    if (name !== undefined) updates.name = name;
    if (role !== undefined) updates.role = role;
    if (active !== undefined) updates.active = active;
    if (centTrab !== undefined) updates.centTrab = centTrab;
    if (password !== undefined) updates.password = password;

    const [user] = await db
      .update(usersTable)
      .set(updates)
      .where(eq(usersTable.id, id))
      .returning();
    if (!user) return res.status(404).json({ error: "Usuário não encontrado" });
    return res.json({
      id: user.id,
      matricula: user.matricula,
      name: user.name,
      role: user.role,
      active: user.active,
      centTrab: user.centTrab,
      createdAt: user.createdAt,
    });
  } catch (err) {
    req.log.error({ err }, "Error updating user");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/users/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(usersTable).where(eq(usersTable.id, id));
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error deleting user");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
