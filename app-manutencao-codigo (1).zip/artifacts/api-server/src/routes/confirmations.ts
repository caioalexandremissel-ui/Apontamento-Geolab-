import { Router } from "express";
import { db, confirmationsTable, serviceOrderLinesTable, serviceOrdersTable, usersTable, rootCausesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

async function enrichConfirmation(c: any) {
  let lineDescription: string | null = null;
  let serviceOrderId: number | null = null;
  let serviceOrderNumber: string | null = null;
  let employeeName: string | null = null;
  let rootCauseName: string | null = null;

  try {
    const [line] = await db
      .select()
      .from(serviceOrderLinesTable)
      .where(eq(serviceOrderLinesTable.id, c.lineId));
    if (line) {
      lineDescription = line.description;
      serviceOrderId = line.serviceOrderId;
      const [order] = await db
        .select()
        .from(serviceOrdersTable)
        .where(eq(serviceOrdersTable.id, line.serviceOrderId));
      if (order) serviceOrderNumber = order.orderNumber;
    }
  } catch {}

  try {
    const [user] = await db
      .select()
      .from(usersTable)
      .where(eq(usersTable.matricula, c.employeeMatricula));
    if (user) employeeName = user.name;
  } catch {}

  if (c.rootCauseId) {
    try {
      const [rc] = await db.select().from(rootCausesTable).where(eq(rootCausesTable.id, c.rootCauseId));
      if (rc) rootCauseName = rc.description;
    } catch {}
  }

  return {
    id: c.id,
    lineId: c.lineId,
    employeeMatricula: c.employeeMatricula,
    employeeName,
    coWorkerMatricula: c.coWorkerMatricula,
    startDate: c.startDate,
    startTime: c.startTime,
    endDate: c.endDate,
    endTime: c.endTime,
    realWork: c.realWork ? Number(c.realWork) : null,
    observation: c.observation,
    rootCauseId: c.rootCauseId,
    rootCauseName,
    status: c.status,
    justification: c.justification,
    photos: c.photos,
    pausedAt: c.pausedAt,
    totalPausedMinutes: c.totalPausedMinutes ? Number(c.totalPausedMinutes) : 0,
    serviceOrderId,
    serviceOrderNumber,
    lineDescription,
    createdAt: c.createdAt,
  };
}

function calcRealWork(startDate: string, startTime: string, endDate: string, endTime: string): number {
  try {
    const start = new Date(`${startDate}T${startTime}`);
    const end = new Date(`${endDate}T${endTime}`);
    const diffMs = end.getTime() - start.getTime();
    const diffH = diffMs / (1000 * 60 * 60);
    return Math.max(0, Math.round(diffH * 10) / 10);
  } catch {
    return 0;
  }
}

router.get("/confirmations/overtime", async (req, res) => {
  try {
    const confs = await db
      .select()
      .from(confirmationsTable)
      .where(eq(confirmationsTable.status, "overtime_pending"));
    const enriched = await Promise.all(confs.map(enrichConfirmation));
    return res.json(enriched);
  } catch (err) {
    req.log.error({ err }, "Error listing overtime confirmations");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/confirmations", async (req, res) => {
  try {
    const { lineId, matricula, status, serviceOrderId } = req.query;
    let confs = await db.select().from(confirmationsTable);

    if (lineId) confs = confs.filter((c) => c.lineId === parseInt(lineId as string));
    if (matricula) confs = confs.filter((c) => c.employeeMatricula === matricula);
    if (status) confs = confs.filter((c) => c.status === status);

    if (serviceOrderId) {
      const lines = await db
        .select()
        .from(serviceOrderLinesTable)
        .where(eq(serviceOrderLinesTable.serviceOrderId, parseInt(serviceOrderId as string)));
      const lineIds = new Set(lines.map((l) => l.id));
      confs = confs.filter((c) => lineIds.has(c.lineId));
    }

    const enriched = await Promise.all(confs.map(enrichConfirmation));
    return res.json(enriched);
  } catch (err) {
    req.log.error({ err }, "Error listing confirmations");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/confirmations", async (req, res) => {
  try {
    const { lineId, employeeMatricula, startDate, startTime } = req.body;
    if (!lineId || !employeeMatricula) {
      return res.status(400).json({ error: "lineId e employeeMatricula são obrigatórios" });
    }

    const now = new Date();
    const date = startDate || now.toISOString().split("T")[0];
    const time = startTime || now.toTimeString().slice(0, 8);

    const [conf] = await db
      .insert(confirmationsTable)
      .values({
        lineId,
        employeeMatricula,
        startDate: date,
        startTime: time,
        status: "started",
      })
      .returning();

    const enriched = await enrichConfirmation(conf);
    return res.status(201).json(enriched);
  } catch (err) {
    req.log.error({ err }, "Error creating confirmation");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/confirmations/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [conf] = await db.select().from(confirmationsTable).where(eq(confirmationsTable.id, id));
    if (!conf) return res.status(404).json({ error: "Apontamento não encontrado" });
    return res.json(await enrichConfirmation(conf));
  } catch (err) {
    req.log.error({ err }, "Error getting confirmation");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.put("/confirmations/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { coWorkerMatricula, endDate, endTime, observation, rootCauseId, justification, status } = req.body;
    const updates: Record<string, any> = {};
    if (coWorkerMatricula !== undefined) updates.coWorkerMatricula = coWorkerMatricula;
    if (endDate !== undefined) updates.endDate = endDate;
    if (endTime !== undefined) updates.endTime = endTime;
    if (observation !== undefined) updates.observation = observation;
    if (rootCauseId !== undefined) updates.rootCauseId = rootCauseId;
    if (justification !== undefined) updates.justification = justification;
    if (status !== undefined) updates.status = status;

    const [conf] = await db
      .update(confirmationsTable)
      .set(updates)
      .where(eq(confirmationsTable.id, id))
      .returning();
    if (!conf) return res.status(404).json({ error: "Apontamento não encontrado" });
    return res.json(await enrichConfirmation(conf));
  } catch (err) {
    req.log.error({ err }, "Error updating confirmation");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/confirmations/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(confirmationsTable).where(eq(confirmationsTable.id, id));
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error deleting confirmation");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/confirmations/:id/pause", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [existing] = await db.select().from(confirmationsTable).where(eq(confirmationsTable.id, id));
    if (!existing) return res.status(404).json({ error: "Apontamento não encontrado" });
    if (existing.status !== "started") return res.status(400).json({ error: "Apontamento não está em andamento" });

    const now = new Date();
    const pausedAt = now.toISOString();

    const [conf] = await db
      .update(confirmationsTable)
      .set({ status: "paused", pausedAt })
      .where(eq(confirmationsTable.id, id))
      .returning();

    return res.json(await enrichConfirmation(conf));
  } catch (err) {
    req.log.error({ err }, "Error pausing confirmation");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/confirmations/:id/resume", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [existing] = await db.select().from(confirmationsTable).where(eq(confirmationsTable.id, id));
    if (!existing) return res.status(404).json({ error: "Apontamento não encontrado" });
    if (existing.status !== "paused") return res.status(400).json({ error: "Apontamento não está pausado" });

    let totalPausedMinutes = Number(existing.totalPausedMinutes || 0);
    if (existing.pausedAt) {
      const pausedStart = new Date(existing.pausedAt);
      const pausedEnd = new Date();
      const pauseDurationMinutes = (pausedEnd.getTime() - pausedStart.getTime()) / (1000 * 60);
      totalPausedMinutes += pauseDurationMinutes;
    }

    const [conf] = await db
      .update(confirmationsTable)
      .set({ status: "started", pausedAt: null, totalPausedMinutes: String(totalPausedMinutes) })
      .where(eq(confirmationsTable.id, id))
      .returning();

    return res.json(await enrichConfirmation(conf));
  } catch (err) {
    req.log.error({ err }, "Error resuming confirmation");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/confirmations/:id/finish", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { endDate, endTime, observation, coWorkerMatricula, rootCauseId, justification, photos } = req.body;

    const [existing] = await db.select().from(confirmationsTable).where(eq(confirmationsTable.id, id));
    if (!existing) return res.status(404).json({ error: "Apontamento não encontrado" });

    const now = new Date();
    const finalEndDate = endDate || now.toISOString().split("T")[0];
    const finalEndTime = endTime || now.toTimeString().slice(0, 8);

    let rawWork = existing.startDate && existing.startTime
      ? calcRealWork(existing.startDate, existing.startTime, finalEndDate, finalEndTime)
      : null;
    // Subtract accumulated pause time
    const pausedMinutes = Number(existing.totalPausedMinutes || 0);
    const realWork = rawWork !== null ? Math.max(0, Math.round((rawWork - pausedMinutes / 60) * 10) / 10) : null;

    const updates: Record<string, any> = {
      endDate: finalEndDate,
      endTime: finalEndTime,
      observation,
      status: "finished",
      realWork,
    };
    if (coWorkerMatricula !== undefined) updates.coWorkerMatricula = coWorkerMatricula;
    if (rootCauseId !== undefined) updates.rootCauseId = rootCauseId;
    if (justification !== undefined) updates.justification = justification;
    if (photos !== undefined) updates.photos = photos;

    const [conf] = await db
      .update(confirmationsTable)
      .set(updates)
      .where(eq(confirmationsTable.id, id))
      .returning();

    return res.json(await enrichConfirmation(conf));
  } catch (err) {
    req.log.error({ err }, "Error finishing confirmation");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
