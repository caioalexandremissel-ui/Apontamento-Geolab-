import { Router, type IRouter } from "express";
import healthRouter from "./health";
import authRouter from "./auth";
import usersRouter from "./users";
import serviceOrdersRouter from "./service-orders";
import serviceOrderLinesRouter from "./service-order-lines";
import confirmationsRouter from "./confirmations";
import editRequestsRouter from "./edit-requests";
import rootCausesRouter from "./root-causes";
import maintenanceCodesRouter from "./maintenance-codes";
import exportRouter from "./export";
import dashboardRouter from "./dashboard";
import signaturesRouter from "./signatures";

const router: IRouter = Router();

router.use(healthRouter);
router.use(authRouter);
router.use(usersRouter);
router.use(serviceOrdersRouter);
router.use(serviceOrderLinesRouter);
router.use(confirmationsRouter);
router.use(editRequestsRouter);
router.use(rootCausesRouter);
router.use(maintenanceCodesRouter);
router.use(exportRouter);
router.use(dashboardRouter);
router.use(signaturesRouter);

export default router;
