import { Router } from "express";
import { db, serviceOrdersTable, serviceOrderLinesTable, confirmationsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

function mapOrder(o: any) {
  return {
    id: o.id,
    orderNumber: o.orderNumber,
    description: o.description,
    type: o.type,
    status: o.status,
    equipment: o.equipment,
    costCenter: o.costCenter,
    location: o.location,
    expectedDuration: o.expectedDuration ? Number(o.expectedDuration) : null,
    openDate: o.openDate,
    center: o.center,
    area: o.area,
    activityType: o.activityType,
    assignedMatricula: o.assignedMatricula || null,
    assignedName: o.assignedName || null,
    createdAt: o.createdAt,
    lines: [],
  };
}

router.get("/service-orders/summary", async (req, res) => {
  try {
    const orders = await db.select().from(serviceOrdersTable);
    const confirmations = await db.select().from(confirmationsTable);

    const total = orders.length;
    const open = orders.filter((o) => o.status === "open").length;
    const inProgress = orders.filter((o) => o.status === "in_progress").length;
    const completed = orders.filter((o) => o.status === "completed").length;
    const preventive = orders.filter((o) => o.type === "preventive").length;
    const corrective = orders.filter((o) => o.type === "corrective").length;
    const pendingConfirmations = confirmations.filter((c) => c.status === "started" || c.status === "overtime_pending").length;

    return res.json({ total, open, inProgress, completed, preventive, corrective, pendingConfirmations });
  } catch (err) {
    req.log.error({ err }, "Error getting service orders summary");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/service-orders/import", (req, res) => {
  return res.json({ message: "Use POST /service-orders/import" });
});

router.post("/service-orders/import", async (req, res) => {
  try {
    const { orders } = req.body;
    if (!Array.isArray(orders)) {
      return res.status(400).json({ error: "orders deve ser uma lista" });
    }

    let imported = 0;
    let skipped = 0;
    const errors: string[] = [];

    for (const order of orders) {
      try {
        const existing = await db
          .select()
          .from(serviceOrdersTable)
          .where(eq(serviceOrdersTable.orderNumber, order.orderNumber));
        if (existing.length > 0) {
          skipped++;
          continue;
        }
        await db.insert(serviceOrdersTable).values({
          orderNumber: order.orderNumber,
          description: order.description,
          type: order.type || "preventive",
          status: order.status || "open",
          equipment: order.equipment,
          costCenter: order.costCenter,
          location: order.location,
          expectedDuration: order.expectedDuration,
          openDate: order.openDate,
          center: order.center,
          area: order.area,
          activityType: order.activityType,
        });
        imported++;
      } catch (e: any) {
        errors.push(`${order.orderNumber}: ${e.message}`);
      }
    }

    return res.json({ imported, skipped, errors });
  } catch (err) {
    req.log.error({ err }, "Error importing service orders");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/service-orders", async (req, res) => {
  try {
    const { type, status, assignedTo } = req.query;
    let orders = await db.select().from(serviceOrdersTable);
    if (type) orders = orders.filter((o) => o.type === type);
    if (status) orders = orders.filter((o) => o.status === status);
    return res.json(orders.map(mapOrder));
  } catch (err) {
    req.log.error({ err }, "Error listing service orders");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/service-orders", async (req, res) => {
  try {
    const { orderNumber, description, type = "preventive", status = "open", equipment, costCenter, location, expectedDuration, openDate, center, area, activityType } = req.body;
    if (!orderNumber || !description) {
      return res.status(400).json({ error: "Número da ordem e descrição são obrigatórios" });
    }
    const [order] = await db
      .insert(serviceOrdersTable)
      .values({ orderNumber, description, type, status, equipment, costCenter, location, expectedDuration, openDate, center, area, activityType })
      .returning();
    return res.status(201).json(mapOrder(order));
  } catch (err: any) {
    req.log.error({ err }, "Error creating service order");
    if (err.code === "23505") {
      return res.status(409).json({ error: "Ordem já cadastrada" });
    }
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/service-orders/:id/lines", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const lines = await db
      .select()
      .from(serviceOrderLinesTable)
      .where(eq(serviceOrderLinesTable.serviceOrderId, id));

    const confirmations = await db.select().from(confirmationsTable);

    return res.json(
      lines.map((l) => ({
        id: l.id,
        serviceOrderId: l.serviceOrderId,
        opNumber: l.opNumber,
        subOp: l.subOp,
        centTrab: l.centTrab,
        cen: l.cen,
        description: l.description,
        expectedTime: l.expectedTime ? Number(l.expectedTime) : null,
        cap: l.cap ? Number(l.cap) : null,
        confirmations: confirmations
          .filter((c) => c.lineId === l.id)
          .map((c) => ({
            id: c.id,
            lineId: c.lineId,
            employeeMatricula: c.employeeMatricula,
            coWorkerMatricula: c.coWorkerMatricula,
            startDate: c.startDate,
            startTime: c.startTime,
            endDate: c.endDate,
            endTime: c.endTime,
            realWork: c.realWork ? Number(c.realWork) : null,
            observation: c.observation,
            rootCauseId: c.rootCauseId,
            status: c.status,
            justification: c.justification,
            createdAt: c.createdAt,
          })),
      }))
    );
  } catch (err) {
    req.log.error({ err }, "Error getting service order lines");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/service-orders/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [order] = await db.select().from(serviceOrdersTable).where(eq(serviceOrdersTable.id, id));
    if (!order) return res.status(404).json({ error: "Ordem não encontrada" });
    const lines = await db
      .select()
      .from(serviceOrderLinesTable)
      .where(eq(serviceOrderLinesTable.serviceOrderId, id));
    const confirmations = await db.select().from(confirmationsTable);
    const result = mapOrder(order);
    result.lines = lines.map((l: any) => ({
      id: l.id,
      serviceOrderId: l.serviceOrderId,
      opNumber: l.opNumber,
      subOp: l.subOp,
      centTrab: l.centTrab,
      cen: l.cen,
      description: l.description,
      expectedTime: l.expectedTime ? Number(l.expectedTime) : null,
      cap: l.cap ? Number(l.cap) : null,
      confirmations: confirmations
        .filter((c) => c.lineId === l.id)
        .map((c) => ({
          id: c.id,
          lineId: c.lineId,
          employeeMatricula: c.employeeMatricula,
          coWorkerMatricula: c.coWorkerMatricula,
          startDate: c.startDate,
          startTime: c.startTime,
          endDate: c.endDate,
          endTime: c.endTime,
          realWork: c.realWork ? Number(c.realWork) : null,
          observation: c.observation,
          rootCauseId: c.rootCauseId,
          status: c.status,
          justification: c.justification,
          photos: c.photos,
          pausedAt: c.pausedAt,
          totalPausedMinutes: c.totalPausedMinutes ? Number(c.totalPausedMinutes) : 0,
          createdAt: c.createdAt,
        })),
    }));
    return res.json(result);
  } catch (err) {
    req.log.error({ err }, "Error getting service order");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.put("/service-orders/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { description, type, status, equipment, costCenter, location, assignedMatricula, assignedName } = req.body;
    const updates: Record<string, any> = {};
    if (description !== undefined) updates.description = description;
    if (type !== undefined) updates.type = type;
    if (status !== undefined) updates.status = status;
    if (equipment !== undefined) updates.equipment = equipment;
    if (costCenter !== undefined) updates.costCenter = costCenter;
    if (location !== undefined) updates.location = location;
    if (assignedMatricula !== undefined) updates.assignedMatricula = assignedMatricula;
    if (assignedName !== undefined) updates.assignedName = assignedName;

    const [order] = await db
      .update(serviceOrdersTable)
      .set(updates)
      .where(eq(serviceOrdersTable.id, id))
      .returning();
    if (!order) return res.status(404).json({ error: "Ordem não encontrada" });
    return res.json(mapOrder(order));
  } catch (err) {
    req.log.error({ err }, "Error updating service order");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/service-orders/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(serviceOrdersTable).where(eq(serviceOrdersTable.id, id));
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error deleting service order");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
