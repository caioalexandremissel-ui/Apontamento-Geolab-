import { Router } from "express";
import { db, editRequestsTable, confirmationsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

async function enrichRequest(r: any) {
  let requestedByName: string | null = null;
  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.matricula, r.requestedBy));
    if (user) requestedByName = user.name;
  } catch {}
  return {
    id: r.id,
    confirmationId: r.confirmationId,
    requestedBy: r.requestedBy,
    requestedByName,
    reason: r.reason,
    status: r.status,
    approvedBy: r.approvedBy,
    createdAt: r.createdAt,
  };
}

router.get("/edit-requests", async (req, res) => {
  try {
    const { status, requestedBy } = req.query;
    let requests = await db.select().from(editRequestsTable);
    if (status) requests = requests.filter((r) => r.status === status);
    if (requestedBy) requests = requests.filter((r) => r.requestedBy === requestedBy);
    const enriched = await Promise.all(requests.map(enrichRequest));
    return res.json(enriched);
  } catch (err) {
    req.log.error({ err }, "Error listing edit requests");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/edit-requests", async (req, res) => {
  try {
    const { confirmationId, reason } = req.body;
    if (!confirmationId || !reason) {
      return res.status(400).json({ error: "confirmationId e reason são obrigatórios" });
    }

    const authHeader = req.headers.authorization || "";
    let requestedBy = "desconhecido";
    if (authHeader.startsWith("Bearer ")) {
      const token = authHeader.replace("Bearer ", "");
      try {
        requestedBy = Buffer.from(token, "base64").toString("utf-8").split(":")[0];
      } catch {}
    }

    const [request] = await db
      .insert(editRequestsTable)
      .values({ confirmationId, requestedBy, reason, status: "pending" })
      .returning();

    return res.status(201).json(await enrichRequest(request));
  } catch (err) {
    req.log.error({ err }, "Error creating edit request");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.get("/edit-requests/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [request] = await db.select().from(editRequestsTable).where(eq(editRequestsTable.id, id));
    if (!request) return res.status(404).json({ error: "Solicitação não encontrada" });
    return res.json(await enrichRequest(request));
  } catch (err) {
    req.log.error({ err }, "Error getting edit request");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.put("/edit-requests/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { status, approvedBy } = req.body;

    const updates: Record<string, any> = {};
    if (status !== undefined) updates.status = status;
    if (approvedBy !== undefined) updates.approvedBy = approvedBy;

    const [request] = await db
      .update(editRequestsTable)
      .set(updates)
      .where(eq(editRequestsTable.id, id))
      .returning();

    if (!request) return res.status(404).json({ error: "Solicitação não encontrada" });

    if (status === "approved") {
      await db
        .update(confirmationsTable)
        .set({ status: "edited" })
        .where(eq(confirmationsTable.id, request.confirmationId));
    }

    return res.json(await enrichRequest(request));
  } catch (err) {
    req.log.error({ err }, "Error updating edit request");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
