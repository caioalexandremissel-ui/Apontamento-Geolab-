import { Router } from "express";
import { db, rootCausesTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/root-causes", async (req, res) => {
  try {
    const causes = await db.select().from(rootCausesTable);
    return res.json(causes.map((c) => ({ id: c.id, code: c.code, description: c.description })));
  } catch (err) {
    req.log.error({ err }, "Error listing root causes");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.post("/root-causes", async (req, res) => {
  try {
    const { code, description } = req.body;
    if (!code || !description) {
      return res.status(400).json({ error: "code e description são obrigatórios" });
    }
    const [cause] = await db.insert(rootCausesTable).values({ code, description }).returning();
    return res.status(201).json({ id: cause.id, code: cause.code, description: cause.description });
  } catch (err: any) {
    req.log.error({ err }, "Error creating root cause");
    if (err.code === "23505") return res.status(409).json({ error: "Código já cadastrado" });
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.put("/root-causes/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const { code, description } = req.body;
    const updates: Record<string, any> = {};
    if (code !== undefined) updates.code = code;
    if (description !== undefined) updates.description = description;

    const [cause] = await db.update(rootCausesTable).set(updates).where(eq(rootCausesTable.id, id)).returning();
    if (!cause) return res.status(404).json({ error: "Causa raiz não encontrada" });
    return res.json({ id: cause.id, code: cause.code, description: cause.description });
  } catch (err) {
    req.log.error({ err }, "Error updating root cause");
    return res.status(500).json({ error: "Erro interno" });
  }
});

router.delete("/root-causes/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    await db.delete(rootCausesTable).where(eq(rootCausesTable.id, id));
    return res.status(204).send();
  } catch (err) {
    req.log.error({ err }, "Error deleting root cause");
    return res.status(500).json({ error: "Erro interno" });
  }
});

export default router;
