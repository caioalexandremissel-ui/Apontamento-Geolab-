import { pgTable, text, serial, timestamp, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { serviceOrderLinesTable } from "./service_order_lines";
import { rootCausesTable } from "./root_causes";

export const confirmationsTable = pgTable("confirmations", {
  id: serial("id").primaryKey(),
  lineId: integer("line_id").notNull().references(() => serviceOrderLinesTable.id, { onDelete: "cascade" }),
  employeeMatricula: text("employee_matricula").notNull(),
  coWorkerMatricula: text("co_worker_matricula"),
  startDate: text("start_date"),
  startTime: text("start_time"),
  endDate: text("end_date"),
  endTime: text("end_time"),
  realWork: numeric("real_work"),
  observation: text("observation"),
  rootCauseId: integer("root_cause_id").references(() => rootCausesTable.id),
  status: text("status").notNull().default("started"),
  justification: text("justification"),
  photos: text("photos"),
  pausedAt: text("paused_at"),
  totalPausedMinutes: numeric("total_paused_minutes").default("0"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertConfirmationSchema = createInsertSchema(confirmationsTable).omit({ id: true, createdAt: true });
export type InsertConfirmation = z.infer<typeof insertConfirmationSchema>;
export type Confirmation = typeof confirmationsTable.$inferSelect;
