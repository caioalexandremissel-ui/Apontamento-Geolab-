import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const rootCausesTable = pgTable("root_causes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  description: text("description").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertRootCauseSchema = createInsertSchema(rootCausesTable).omit({ id: true, createdAt: true });
export type InsertRootCause = z.infer<typeof insertRootCauseSchema>;
export type RootCause = typeof rootCausesTable.$inferSelect;
