import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { serviceOrdersTable } from "./service_orders";

export const signaturesTable = pgTable("signatures", {
  id: serial("id").primaryKey(),
  serviceOrderId: integer("service_order_id").notNull().references(() => serviceOrdersTable.id, { onDelete: "cascade" }),
  signerType: text("signer_type").notNull(), // executor | area_responsible | immediate_supervisor
  signerName: text("signer_name").notNull(),
  signerMatricula: text("signer_matricula"),
  signatureData: text("signature_data").notNull(), // base64 PNG da assinatura desenhada
  signedAt: timestamp("signed_at", { withTimezone: true }).notNull().defaultNow(),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertSignatureSchema = createInsertSchema(signaturesTable).omit({ id: true, createdAt: true, signedAt: true });
export type InsertSignature = z.infer<typeof insertSignatureSchema>;
export type Signature = typeof signaturesTable.$inferSelect;
