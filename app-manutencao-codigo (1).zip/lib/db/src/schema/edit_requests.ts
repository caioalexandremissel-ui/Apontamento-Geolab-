import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { confirmationsTable } from "./confirmations";

export const editRequestsTable = pgTable("edit_requests", {
  id: serial("id").primaryKey(),
  confirmationId: integer("confirmation_id").notNull().references(() => confirmationsTable.id, { onDelete: "cascade" }),
  requestedBy: text("requested_by").notNull(),
  reason: text("reason").notNull(),
  status: text("status").notNull().default("pending"),
  approvedBy: text("approved_by"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertEditRequestSchema = createInsertSchema(editRequestsTable).omit({ id: true, createdAt: true });
export type InsertEditRequest = z.infer<typeof insertEditRequestSchema>;
export type EditRequest = typeof editRequestsTable.$inferSelect;
