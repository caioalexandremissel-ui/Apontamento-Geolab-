import { pgTable, text, serial, timestamp, numeric } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const serviceOrdersTable = pgTable("service_orders", {
  id: serial("id").primaryKey(),
  orderNumber: text("order_number").notNull().unique(),
  description: text("description").notNull(),
  type: text("type").notNull().default("preventive"),
  status: text("status").notNull().default("open"),
  equipment: text("equipment"),
  costCenter: text("cost_center"),
  location: text("location"),
  expectedDuration: numeric("expected_duration"),
  openDate: text("open_date"),
  center: text("center"),
  area: text("area"),
  activityType: text("activity_type"),
  assignedMatricula: text("assigned_matricula"),
  assignedName: text("assigned_name"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertServiceOrderSchema = createInsertSchema(serviceOrdersTable).omit({ id: true, createdAt: true });
export type InsertServiceOrder = z.infer<typeof insertServiceOrderSchema>;
export type ServiceOrder = typeof serviceOrdersTable.$inferSelect;
