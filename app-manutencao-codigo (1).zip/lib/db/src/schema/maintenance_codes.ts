import { pgTable, text, serial, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const maintenanceCodesTable = pgTable("maintenance_codes", {
  id: serial("id").primaryKey(),
  code: text("code").notNull().unique(),
  name: text("name").notNull(),
  type: text("type").notNull().default("preventive"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertMaintenanceCodeSchema = createInsertSchema(maintenanceCodesTable).omit({ id: true, createdAt: true });
export type InsertMaintenanceCode = z.infer<typeof insertMaintenanceCodeSchema>;
export type MaintenanceCode = typeof maintenanceCodesTable.$inferSelect;
