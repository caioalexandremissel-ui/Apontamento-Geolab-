import { pgTable, text, serial, timestamp, numeric, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { serviceOrdersTable } from "./service_orders";

export const serviceOrderLinesTable = pgTable("service_order_lines", {
  id: serial("id").primaryKey(),
  serviceOrderId: integer("service_order_id").notNull().references(() => serviceOrdersTable.id, { onDelete: "cascade" }),
  opNumber: text("op_number").notNull(),
  subOp: text("sub_op"),
  centTrab: text("cent_trab"),
  cen: text("cen"),
  description: text("description").notNull(),
  expectedTime: numeric("expected_time"),
  cap: numeric("cap"),
  assignedMatricula: text("assigned_matricula"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertServiceOrderLineSchema = createInsertSchema(serviceOrderLinesTable).omit({ id: true, createdAt: true });
export type InsertServiceOrderLine = z.infer<typeof insertServiceOrderLineSchema>;
export type ServiceOrderLine = typeof serviceOrderLinesTable.$inferSelect;
